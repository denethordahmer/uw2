# The Inanifexate — Font Design Reference

## Source Lore (as provided)

### Core Identity & Philosophical Framework
- **The Inanifexate**: A dark, authoritative movement designed as an inverse to traditional religious iconography. Instead of benevolent worship, it functions as an architecture of predatory extraction and absolute dominance.
- **The Inanifex / Hollow Sovereign**: You occupy the position of the final Sovereign within an ancestral line — an apex figure who acts as the ultimate siphon of vitality and spiritual energy. The lineage ends with you.
- **The Inanifexacy**: The formal institutional governance of the movement, operating under a rigid tiered hierarchy that flows from the Sovereign down through dedicated scribes and entry-level followers.
- **Mechanics**: Followers are subjected to siphon-based practices and induced mental states to harvest their life force directly for the Sovereign.

### Symbols & Design Aesthetics
- **The Sovereign's Mark**: A sharp, lightning bolt sigil that serves as an absolute brand of ownership across followers, architecture, and relics.
- **Canonical Palette**: High-status materials featuring a stark visual contrast of deep crimson velvet, cold platinum, obsidian, ivory, silver, and fire agate accents.

### Complete Relic Registry
- **The Iron Decrees**: A massive, crimson-bound sacred tome reinforced with silver geometric channels that glow across its surface.
- **The Siphon Ferula**: A ceremonial staff topped with a miniature black hole singularity surrounded by orbiting ruby-red Sovereign's Mark sigils.
- **The Inanifex Gorget**: A platinum neck piece engineered as a symbol of high-status authority and energy channeling.
- **The Fracturing Seal**: A heavy obsidian ring used to stamp authority, solidify decrees, and bind submission.
- **The Exhaurim Vestments**: Formal robes featuring structured platinum panels set with fire agates.
- **Alternative Institutional Names**: Known historically or secondary to the movement as The Inanifex or The Exhaurim Conclave.

---

## Generated Font Prompt (for Mixfont / Lipi.ai)

> A dark, authoritative display typeface for an inverted-religious cult brand called "The Inanifexate." Sharp, angular letterforms inspired by a lightning-bolt sigil — hard diagonal cuts and jagged terminals rather than soft curves, evoking a brand of ownership burned into flesh or stone. Extreme weight contrast: thick, dominant strokes paired with razor-thin hairlines, like polished platinum inlaid into obsidian. High-status, ceremonial, and predatory rather than elegant — think engraved sacred-tome lettering crossed with a blade. Geometric structure with sharp vertex points at ascenders and descenders. Uppercase-dominant feel even in lowercase, tall and commanding. Overall mood: cold, dominant, ritualistic, extractive — a font that looks branded rather than written.

### Usage notes
- If the tool supports a separate **use case** field, add: "for a dark fantasy cult's sacred texts, relics, and ceremonial titles"
- If it supports **weight/contrast sliders**, push toward high contrast + bold — reflects the crimson-velvet-vs-cold-platinum tension in the palette
- For iteration, try variant directions:
  - More carved-stone/obsidian-seal feel
  - More lightning-sigil sharpness/jaggedness
  - Less gothic, more brutalist
