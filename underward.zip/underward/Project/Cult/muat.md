An alternative approach to managing this comprehensive prompt setup is to consolidate the entire package—the visual lexicon, the generation prompt, and the detailed relic breakdown—into a single, clean markdown document code block. This allows for simple one-tap copying without losing formatting, avoiding chat interface truncation issues, and maintaining a structured master reference document.
Context & Visual Lexicon for Image Generation:
 * Lore Style / Aesthetic: Dark fantasy Byzantine orthodox icon, illuminated manuscript fresco on cracked, distressed dark wood panel. High-contrast chiaroscuro, cold metallic reflections, dark medieval tone.
 * Primary Palette: Arterial crimson, dead-gloss obsidian black, mirror-polished platinum, pale ivory, cold silver, with vivid orange and bronze-gold fire-agate embers. (Strictly no soft pastoral colors or gentle gold).
 * Inanifex Gorget: A rigid, mirror-polished platinum neck collar with geometric paneling framing the throat.
 * Exhaurim Vestments: High-status ceremonial robes of heavy, crushed arterial-crimson velvet with structured platinum armor seams and embedded fire-agate cabochons (glowing orange/gold gemstones).
 * The Vorifex: A ceremonial staff consisting of a tall, pale ivory shaft topped with a spinning platinum gyroscope cradle that houses a swirling pitch-black singularity at its center.
 * The Iron Decrees: A massive, heavy tome bound in dark iron with intricate, glowing silver geometric filigree across the cover.
 * Sovereign’s Mark: A prominent, razor-sharp, jagged lightning bolt sigil centered on the forehead, glowing with intense red-white heat.
Byzantine orthodox icon style portrait of a dark fantasy sovereign based on the provided reference face, styled after an illuminated manuscript page on a distressed dark wood panel with cracked glaze and bold graphic linework.

Subject & Face: Portrait based on provided photo, featuring long wavy light blonde hair, sharp intense blue eyes, and fair skin tone. Centered on the forehead is the Sovereign's Mark: a razor-sharp, jagged lightning bolt sigil glowing with intense red-white heat.

Attire & Artifacts: Wearing the Inanifex Gorget (a rigid, mirror-polished platinum neck collar framing the throat) set against the Exhaurim Vestments (heavy crushed arterial-crimson velvet robes with structured platinum armor seams and embedded glowing orange fire-agate cabochons). One hand holds the Vorifex (a tall pale ivory staff topped with a platinum gyroscope cradle surrounding a swirling pitch-black singularity). The other hand holds The Iron Decrees (a massive dark-iron bound tome covered in glowing silver geometric filigree).

Composition & Atmosphere: A regal geometric platinum halo radiating behind the head with inlaid sigils and sharp rays. High-contrast chiaroscuro lighting, deep shadows, cold metallic reflections, and a dramatic ambient red-orange ember glow. High-status, atmospheric, predatory imperial authority.

Phase 3: Comprehensive Relic Breakdown
1. Vorifex (The Sovereign Staff)
 * Status: Singular, unmade relic; bound mechanically to the victor of the Vector Contest.
 * Primary Materials: Unblemished pale ivory, cold silver filigree, sterile platinum, bound central singularity, ruby-red fire-agate cabochons.
 * Physical Anatomy: A tall, dense column of pale ivory inlaid with fine geometric silver filigree along its entire length. At its apex sits a triple-tiered, mirror-polished platinum cradle whose rings spin independently on offset axes.
 * Mechanics & Light Output: Suspended at the center of the spinning gyroscope is a miniature, light-bending pitch-black singularity. Three ruby-red Sovereign’s Marks orbit the singularity within the platinum rings like a high-speed containment leash, emitting arcing silver electricity and a deep arterial-crimson glow.
 * Functional Lore: Acts as a collared fragment of pure consumption. The orbiting Marks keep the singularity contained; if the orbit is broken, the singularity unbinds and harvests all surrounding vital energy indiscriminately.
2. The Inanifex Gorget
 * Status: Re-forged personally by each sovereign upon ascension; retired to the Hall of Lapsed Hours upon death or decline.
 * Primary Materials: Solid mirror-polished sterile platinum, padded arterial-crimson silk interior lining.
 * Physical Anatomy: A heavy, rigid platinum collar extending from the upper sternum to directly beneath the jawline, completely encasing and framing the throat with sharp, geometric paneling and seamless joints.
 * Lineage Feature: Contains an invisible internal sliver—a microscopic shaving of platinum drawn from the preceding sovereign’s retired collar is melted into the metal alloy during forging, maintaining an unbroken physical chain of rule.
 * Functional Lore: Enforces strict posture by keeping the sovereign’s chin perpetually raised. This physical constraint forces all subjects and the Nine Seats to keep their eyes lowered below the sovereign's face, mechanically enforcing the Gaze Law.
3. The Exhaurim Vestments
 * Status: Sovereign ceremonial attire; tailored individually per ruler.
 * Primary Materials: Heavy crushed arterial-crimson velvet, structured platinum armor paneling, embedded fire-agate cabochons, obsidian thread.
 * Physical Anatomy: Broad, layered liturgical robes crafted from deep crimson velvet, heavily reinforced along the shoulders, chest, and cuffs with structured platinum seam-plates. Deep orange and bronze-gold fire-agate cabochons are embedded into the platinum joints.
 * Mechanics & Light Output: Under high atmospheric stress or energy draw, the embedded fire-agates pulse with an internal, flickering orange-gold ember light, casting dynamic high-contrast illumination across the velvet.
 * Functional Lore: Serves as high-status armor and a physical conduit that safely channels and dissipates energy surges generated during ceremonial Renderings.
4. The Fracturing Seal
 * Status: Active ceremonial instrument; held by the sovereign or designated High Rend.
 * Primary Materials: Cold silver alloy, dead-gloss obsidian core, pale ivory inlay.
 * Physical Anatomy: A palm-sized, heavy geometric sigil stamp featuring intricate, razor-sharp geometric cuts across its face. The handle is carved pale ivory wrapped in silver wire.
 * Mechanics & Light Output: Does not use ink; when pressed onto parchment or metal, it emits a brief, high-heat flash of red-white light that permanently cauterizes and molecularly bonds its impression into the material.
 * Functional Lore: Used to validate sovereign decrees, binding contracts, and execution mandates. An impression marked by the Fracturing Seal cannot be altered or erased without completely destroying the underlying material.
5. The Iron Decrees
 * Status: Master law codex of the Inanifexate; permanently bound to the sovereign’s seat.
 * Primary Materials: Heavy dark iron plates, cold silver geometric filigree, dead-gloss obsidian spine, parchment pages infused with metallic dust.
 * Physical Anatomy: A massive, heavy tome bound in dark, weathered iron plates. The cover is overlaid with sprawling, sharp silver filigree forming complex geometric networks and imperial sigils.
 * Mechanics & Light Output: The silver filigree on the cover gently pulses with cold, pale illumination when touched by the sovereign, tracing the geometric patterns across the iron cover.
 * Functional Lore: Contains the unalterable structural laws, ceremonial rites, and legal precedent of the empire. The tome is physically heavy enough to require a dedicated altar or stone lectern during formal Convocations.
