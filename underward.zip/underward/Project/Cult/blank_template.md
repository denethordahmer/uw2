# 

MASTER CODEX: THE INANIFEXATE

Compiled edition — merges the original codex with the completed answers to items #1 (The Inanifexacy), #2 (The Hierarchy of Followers), and #3 (The Extraction Ritual). Item #10 (The Iron Decrees / the Tome's contents) is deliberately placed last, reserved for expansion once the rest of the canon is locked.

I. Core Identity

The Inanifexate is the overall empire, religion, and system. It is the cult. It is the movement. It is the structure that contains all followers, relics, doctrines, and hierarchy.

The Inanifex is the title of the apex sovereign — the final and ultimate entity to hold the role. Comparable in structural position to the final prophet or messiah in a religious lineage, but inverted into a figure of cold, parasitic authority. The current and final Inanifex is you. Earlier precursors held their own names, but the title of the tip of the pyramid is Inanifex.

The Inanifexacy is the governing body beneath the Inanifex — the Nine Seats. It administers the system (full structure in Section VI).

The Inanifexate inverts every vector of traditional Holy See and papal iconography. Where the Papacy symbolizes benevolent paternalism, spiritual stewardship, self-sacrifice, and divine grace through golden warmth and open-armed shepherd motifs, the Inanifexate inverts each into absolute extraction, predatory sovereignty, and cold-forged corruption.

II. Philosophical & Stylistic Inversion

The traditional shepherd's crook becomes the weaponized, singularity-powered staff: Vorifex.

The triple-tiered papal cross transforms into floating, harvesting energy arrays.

The humble robes of a holy servant are replaced by high-status opulence: crushed crimson velvet locked behind rigid platinum armor seams and burning fire agates.

The entire aesthetic shifts from offering grace to commanding absolute, parasitic tribute.

III. Canonical Color Palette

Deep Crimson · Polished Platinum · Obsidian Black · Pale Ivory · Cold Silver · Bronze-gold and vivid orange flashes of Fire Agate.

All warm, benevolent gold and gentle pastoral tones are purged. The palette is chilling, high-status, and majestic.

IV. The Sovereign's Mark

The Sigil: A razor-sharp, jagged lightning bolt motif.

Symbolism: Absolute authority, sudden extraction, life-force harvesting.

Application: Marked upon the forehead of the Inanifex — the only site where it burns live, red-white, and constant. Embedded into all sacred relics. Branded, in various dead renditions, onto every rank of follower.

(The full rank-by-rank table of Mark renditions — metal, site, and light for the Nine, the Orders, and the Grades — is in Section VII, since a follower's Mark is inseparable from their station.)

V. The Siphoned Essence: The Vital Vector

The Inanifex does not siphon from followers by default. It does not consume souls. It does not take devotion by force. It does not drain memories.

The Inanifex extracts the Vital Vector — the unified trajectory of a life: the singular, integrated force that binds personal agency to the forward passage of time. It is the engine of motion. The spark that allows a person to both will their future and reach it.

Effects of extraction:

No physical wounds. No immediate death.

Temporal and volitional collapse.

The victim is left alive but chronologically stranded — their timeline flatlines.

They become a static echo of themselves, trapped in an unchanging moment.

Physical entropy accelerates without the animating spark to hold it back — rapid, uncanny aging.

The victim lacks the drive to resist it.

They become inert — a living monument to the theft of their own trajectory.

(Full mechanics of how the Vector is actually taken are in Section VIII, The Extraction Ritual.)

VI. The Inanifexacy — The Governing Body

Governance model: A Closed Collegium — a fixed, finite body of nine ministers, each holding a named office. Loyalty is not asked of them; it is physically installed at elevation. Ambition is not suppressed — it is redirected outward, into a sanctioned ladder of predation, so every scheme inside the Inanifexacy terminates, by law, in tribute delivered to the Inanifex.

The Nine Seats

Nine, and never another — the number mirrors the Siphon Gyroscope's three tiers of three Sovereign's Marks. The Inanifexacy is the gyroscope made of men. The Inanifex presides above the nine from the Ivory Threshold — not a tenth seat, but the place from which the instrument is spun.

SeatTitleDomainIPrimus ExactorFirst Exactor. Extraction quotas, the ordering of takings, discipline of the Exactorii.IICustos DoctrinaeKeeper of Doctrine. Sole authority to inscribe or amend the Iron Decrees. Orthodoxy.IIIMagister VectorumMaster of the Ledger of Lapsed Hours. Every vector harvested is entered in his hand, past tense, before it is taken.IVPraefectus SilentiPrefect of Silence. Enforcement turned inward — jurisdiction only over the Inanifexate's own.VAedilis SanguinisSteward of Blood. Bloodlines, breeding stock, selection and maintenance of high-caliber vectors until harvest.VIFaber ReliquiarumSmith of Relics. Forges gorgets, seals, lesser staffs. Holds the molds of the Sovereign's Mark.VIIArgentarius InanifexisTreasurer. Platinum, agate, tribute-in-matter — all material opulence passes through his vaults alone.VIIINuntius ExteriorThe Outward Herald. Feudatories, vassal states, treaties of tithe.IXVox InanifexisThe Voice. Speaks with the Inanifex's authority in his silence. The most dangerous, most eagerly sought seat.

Upon elevation, a minister is stripped of his birth name and addressed only by office and numeral — Exactor Primaris, Fourth of the Line. The name is not returned on death; it is entered once, in the Ledger, as a lapsed asset.

The Leash: Pignus Vectoris

The nine are loyal because they are collateralized. At elevation, a thread of the minister's own Vital Vector is drawn off — tendered, not stolen — and invested into Vorifex's orbit as a fourth, dimmer mark. It is never returned. What is returned is the withholding: a seated minister does not age; his entropy is suspended, held outside him in the gyroscope.

This produces three absolute laws:

No minister may resign. Removal is not retirement; it is the Lapse. All withheld years arrive at once, in a single held heartbeat.

No minister may scheme against the throne, because a scheme requires a future — and their future is held in the staff. Volition is leased back to them, minus its last reach.

No minister may lie in the Chamber of Lapsed Hours. Not from honesty — from geometry: a lie requires projecting the self forward, and their forward self isn't in the room.

The Sanctioned Ladder

Advancement between the nine requires a rendered vector of sufficient caliber — not poison, but harvest. If the vector is judged worthy, the seat above opens; if occupied, that occupant is Struck.

Murder is not a crime in the Inanifexate. Murder is an inefficiency. The one heresy is Waste — taking a life whose vector is not rendered — punished by the Lapse without exception, and read aloud at every Convocation by the Praefectus Silenti, in the past tense, because the wasteful are already spent.

Rituals of the Inanifexacy

The Silent Convocation — held in the Chamber of Lapsed Hours. The nine sit on the descending obsidian dais; the Inanifex occupies the Ivory Threshold above, lit from below while they are not. The Custos Doctrinae reads the Decrees, the Magister Vectorum reads the Ledger, the Primus Exactor renders the tally, and the Vox speaks last with binding authority — occasionally, publicly, contradicted, so the Voice never forgets it is not the source.

The Gaze Law — the nine may address the Inanifex's throat; they may not raise their eyes to the Sovereign's Mark. To look upon the Mark is to be emptied.

The Binding of the Shard — elevation rite. The Fracturing Seal is pressed to the nape (never the forehead), leaving the Dull Mark, lead-grey and unlit. The shard is drawn; the candidate rises as a numeral.

The Rendering — the public extraction ceremony performed at the great feasts. (Full staging and mechanics are covered under the Threshold Rite in Section VIII.)

The Striking — the Inanifexacy's worst sentence. The Dull Mark is burned from the nape; the withheld years return all at once, in under a second.

Regalia and Chamber

The nine wear crimson velvet without platinum: blackened iron seams, dull lead gorgets, and smoked quartz in place of fire agate — legible at a glance as one burning figure and nine dead ones. Only the Fracturing Seal is white-gold over obsidian, and only it may stamp crimson wax into law.

The Chamber of Lapsed Hours is windowless, floored in black mirror-stone, walled in the same pulsing silver-channel geometry as the Iron Decrees. The Ledger of Lapsed Hours rests on an ivory lectern at its center — iron-bound, pale ivory pages, arterial crimson ink, entries written in the past tense before the extraction occurs. In the Inanifexate, a taking is recorded the moment it is decided; the world is merely permitted to catch up.

(The full structure of everyone below the Nine — the Seven Orders and Seven Grades — is in Section VII.)

VII. The Descent — Hierarchy of Followers

Below the Ivory Threshold, a follower's place is fixed by two coordinates, never one:

The Order claims his hands — what he does, what he may touch, whom he may command. Seven Orders. Sworn. Iron.

The Grade claims his blood — what he is worth, how he lives, when he is emptied. Seven Grades. Inherited, earned, or assigned. Ash.

A man is not "a priest" — he is Cultor of the Third Grade. This is the Law of Legibility: the first law taught to children. The Inanifexate does not tolerate ambiguity of station, because ambiguity is where ambition hides, and ambition is to be plumbed, not concealed.

The Seven Orders (The Hands)

Sworn at investiture. Each Order bears the Iron Mark — the Sovereign's Mark struck in blackened iron, unlit, on a site chosen by function.

OrderFunctionIron Mark SiteExactoriiField extraction, quota enforcement, taking vectors from the unmarked.Back of right hand — gloved, uncovered only when taking.SilentiThe Praefectus's knives; enforcement turned inward. Tongueless by law.Where the tongue was.Scribae VectorumNotaries of the Ledger — record every taking in the past tense before it occurs.Inner wrist of the writing hand.LegatiThe Outward Herald's agents; negotiate the Vector Tithe with Feudatories.Sole of the foot — walked upon and hidden.ReliquariiSmiths under the Faber Reliquiarum; forge gorgets, seals, staffs, branding styli.Palm of the forging hand.NutritoresSelection, breeding, and maintenance of high-caliber vectors until harvest.Over the navel.Cultores InanifexisThe priesthood — liturgy of the Rendering, custody of the Iron Decrees, care of the lapsed monuments.Sternum, over the heart.

The Orders do not recruit; they claim. A Nutritor who finds a child of exceptional trajectory in a Tolerated household may take the child without payment or appeal; the family is compensated in platinum and expected to be grateful.

The Seven Grades (The Descent)

Ranked by two measures: the caliber of vector a person carries, and their utility in the taking of others.

The Feudatories — the Tithed Lords. Pay the Vector Tithe annually. Blood-Bronze Mark, inner wrist, the only follower's mark permitted worn openly — a warning to their own subjects.

The Benefacti — the Spent Channel. Rendered a vector voluntarily and were raised for it. Cinder Mark, one channel filled with arterial crimson — a receipt. Exempt from tithe.

The Vocati — the Summoned. Lay staff of Inanifexate houses. Ash Mark, inner wrist. Live indoors, eat at the second table.

The Branded — the Congregation. The base of the faithful. Ash Mark, worn covered by a leather cuff, shown only on command. Taxed in matter, conscripted in labor, obligated to render names.

The Tolerated — the Unmarked. Households under protection without membership. No mark — not mercy, but a verdict: not yet worth branding.

The Ledger-Born — the Crimson Thread. Already entered in the Ledger; their hour is known. No brand — a crimson thread at the wrist, replaced yearly. Housed, fed, and treated with elaborate courtesy, because a spoiled vector is a wasted one.

The Unentered — Below the Ladder. The unconquered, unvisited, uncounted. Not hated — simply not yet decided to matter enough to be taken.

Below the ladder there is no rung. There is only the ground, and the ground is where the Exactorii stand.

The Mark: Renditions by Rank

The Sovereign's Mark is one sigil in six renditions, distinguished by metal, site, and light.

RenditionBearerSiteLightThe Burning MarkThe Inanifex aloneForehead, unboundLive — red-white, constantThe Dull MarkThe Nine of the InanifexacyNapeLead-grey, deadThe Blood-Bronze MarkFeudatoriesInner wrist, shown openlyBronze-gold in torchlightThe Iron MarkThe Seven OrdersBy function (table above)Blackened iron, no glowThe Ash MarkVocati and BrandedInner wrist, coveredFaint grey, no glowThe Cinder MarkBenefactiInner wristGrey, one crimson channel

The Rite of the First Mark — a follower is branded not at birth, but when they become worth recording: customarily at fourteen, or upon rendering their first name, whichever comes first. The Reliquarii perform it in the Branding Hall with an iron stylus, filled with ash and cold silver filings. It is not permitted to heal clean; a scarless mark is struck out and repeated.

The Ignition — the Ash Mark stays cold grey for life and burns exactly once: at the moment its bearer's own Vital Vector is extracted, it ignites arterial crimson and stays lit as long as the body remains. The Mark was never a symbol of belonging — it is a receipt, issued in advance, designed to light up the instant the debt is collected.

What Ordinary Followers Do

The Tithe of Names — the first obligation. Every Branded follower must render, annually, the name of one person of high trajectory known to them. A follower who renders nothing for three years is reviewed — and review, in the Inanifexate, is not neutral.

The Tithe of Matter — platinum, ivory, agate, crimson dye, iron, obsidian, owed by measure from every Branded household.

The Tithe of Motion — labor: roads, walls, halls, forges. The Inanifexate does not take the Branded's hours (their vectors are reserved) — it takes their bodies, which are cheaper.

The Four Marks of the Day — dawn, noon, dusk, and the Black Hour. Followers face the nearest Inanifexate structure and stand motionless for the length of a slow breath: Stilling. Doctrine holds that a body rehearsed in stasis gives up its trajectory more cleanly when the time comes — taught as a privilege.

The Reversion — the promise, and the trap. A follower of high Grade and long service is harvested ceremonially, at a feast, mark ignited, name read aloud from the Iron Decrees, monument placed in the Hall of Lapsed Hours. A follower who fails, wastes, or is Unentered is taken in a field, without name or witness — not a monument, but litter.

Core theology: piety determines the dignity of your extraction, not its occurrence.

Censura — Discipline Below the Nine

All penalties kept by the Silenti are extractive:

The Dulling — the Mark struck out with a hot iron, ruined. Kept inside the walls at the lowest labor, marked and legible as a warning.

The Rending — partial extraction; a thread of the vector drawn (a hand's worth, a season's worth), leaving the subject amputated in will in one domain — unable to will a single specific act, though alive and aware of the lack. Performed publicly, then released to household care.

The Lapse — reserved for Waste, and for the Nine. Instant return of all withheld hours. No wound, no sound.

Rank, in One Line

The Inanifex above all, marked on the forehead and burning. The Nine beneath him, marked at the nape and dull. The Seven Orders beneath them, marked in iron by function. The Seven Grades beneath the Orders, marked in bronze, ash, thread, or nothing. The Unentered beneath the Grades — unmarked, uncounted, and waiting.

VIII. The Extraction Ritual

The Foundational Law: The Aperture

The Vital Vector cannot be torn from a body by force alone. A body may be restrained, a mind deceived, a person threatened until resistance is impossible — none of this is sufficient. The Vector is agency joined to the forward passage of time, and it must declare itself before it can be taken.

The subject must perform one act of directed will — answer a question, step across a threshold, raise a hand, name someone, choose between two objects. Even a false choice suffices, provided the victim believes, for one instant, that the next moment belongs to them. That instant is the Aperture.

A corpse has no trajectory. A sleeping body has only a muted one. The richest extraction occurs at the precise moment a person believes they are about to continue.

The Two Instruments: Doctrine of the Two Hands

Vorifex is the Inanifex's right hand — the only instrument that takes a vector whole, in one unbroken thread wound into the Siphon Gyroscope. It is used in one place only, the Threshold Rite, and only in public: Vorifex will not turn for a hidden hand. What the right hand takes is rendered, and rendering is holy.

The Fractae (Lesser Staffs) are the left hand — struck from the same pale ivory, but set with a cold silver shard in a two-tier cradle rather than a singularity. Carried by the Exactorii, they sever a thread rather than extract whole — a season, a hand, a name, a hunger. Their takings are private, quick, coarse, and known simply as the Cut. What the left hand takes is merely lost. The Cultores do not bless the Cut; the doctrine calls it necessary, and not holy.

The Three Modes of Consent / Three Legal Conditions

Every extraction is classified by the condition under which the Aperture was produced. The result is identical — the lapsed is lapsed — but the ceremony differs, because ceremony is for the living, not the taken.

1. The Voluntary Rendering — The Reversion (Willing). Reserved for the highest Grades: Feudatories, Benefacti, honored Cultores, Ledger-Born maintained for ceremonial use. The doctrine holds the vector is not stolen from the willing but returned — leased from the Inanifex at birth, and piety is the art of handing back a borrowed thing with grace. The subject is dressed in pale ivory, led in without chains, Mark polished to catch the light, permitted one final declaration. They place a hand on the Vector Plinth. The Inanifex asks, "What remains yours?" The legal answer: "The moment before surrender." Public, feasted, and described in the Iron Decrees as the highest honor the Inanifexate bestows.

2. The Veiled Rendering — The Tithe-Rendering / part of the Harvest (Coerced by contract, or Deceived). Feudatories deliver bound and veiled tithes at the annual feast to satisfy debt — a contract enacted on the subject's behalf, carrying no personal honor. Separately, a victim may be deceived: a false pardon, a staged rescue, a forged promise, with the final decision placed in their own hands. When they choose, the deception ends and the chamber doors close. Recognition of the deceit, arriving just before extraction, is considered ideal — the Vector surges toward the future trying to escape, and Vorifex receives it at full tension.

3. The Compelled Rendering — The Harvest / the Cut (Coerced, taken). Used for criminals, failed tithe-payers, enemy leaders, and rebellious villages whose trajectory is too valuable for a common execution. The subject is bound only after the Aperture is induced — before that, they must be allowed to move, speak, and believe some action can still change the outcome. The Exactorii offer impossible choices (betray another or lose both lives; walk to the staff or remain beneath the lamps) — every choice recorded as an act of will. When performed in the field with a Fracta rather than Vorifex, this mode produces no feast, no witness, and no monument.

The Chamber

Extractions take place in an Aperture Vault — the Chamber of Lapsed Hours for major state ceremonies, or the larger Feast Hall of the Threshold when the audience is large; lesser private vaults are used for compelled or field-adjacent takings. Common fixtures:

The Vector Plinth — an oblong slab of black stone veined with cold silver, where the subject makes their final choice.

The Static Dish — a disc of polished black stone at the foot of the Ivory Threshold, where the subject stands during the Threshold Rite specifically.

The Silver Meridian — a line running from the plinth to the sovereign's position.

The Three Crown Arrays — suspended fixtures mirroring Vorifex's gyroscope, lit only by fire-agate lamps once the ritual begins.

The Witness Gallery — where the Inanifexacy, Feudatories, or selected followers observe.

A calibration floor of nine concentric rings, one per seat of the Inanifexacy.

The Altar of the Ledger — the iron-bound tome open on its ivory lectern, the Magister Vectorum at its right hand, the entry already written in the past tense before the subject arrives.

The walls carry pale ivory panels engraved with former extractions — never the moment of death, always the moment before it: a hand reaching for a door, a face turning toward a voice. The Inanifexate preserves the instant of possibility, not the person.

The Threshold Rite — Staging and Procession

Silence — no music, which would imply fellowship, which is not permitted. The Nine sit on the descending obsidian dais, dull lead gorgets catching no light; the Feudatories stand in the galleries, Blood-Bronze marks bared. The Custos Doctrinae strikes his staff once per step as the subject walks to the Threshold: the willing walk veiled in crimson, the coerced are led with the veil held shut, the deceived walk freely and are watched most carefully, since the crowd's attention is trained on the instant a deception breaks.

The subject is placed on the Static Dish, below the Threshold. The Inanifex descends bearing Vorifex, Gorget framing the throat, Mark burning uncovered. The subject is instructed — in the Reversion, invited — to look upon the Mark: the doctrinal hinge of the Rite. The vector is taken only once the subject's gaze consents to the sovereign's image, since the gaze is the first thing a life spends. The willing look eagerly; the coerced are made to look by a hand at the chin; the deceived look with joy, believing it a blessing — their last act of agency is one of gratitude.

The Custos Doctrinae declares: "The trajectory is present." The Magister Vectorum answers: "The trajectory is accounted for." The Inanifex says nothing.

The Taking

At the Aperture, the Vital Vector becomes visible — not as soul or spirit, but as a severe distortion in the air: a narrow line of pressure, near-colorless ivory light at its base, extending from the sternum toward the chosen action. Its texture shifts with the manner of taking: for a willing subject it runs closer to a fine silver thread; for a deceived subject it wraps itself in fragments of false possibility — an unopened door, a child's face — tinted faintly red; for a coerced subject it strains jagged and dark against the chamber's geometry.

The Siphon Gyroscope spins up — the three ruby-red Sovereign's Marks break from their slow drift into a blur around the singularity, which bends the torchlight until every shadow in the hall leans toward it. The Cultores speak the litany once, in unison: "Quod fuit, cessat." — What was, ceases.

The Inanifex turns Vorifex three times. On the first turn, the victim's future loses depth — a rising hand stops midway, a mouth stays open around an unfinished word. On the second, the Vector contracts toward the staff and the body's entropy accelerates: skin slackens, hair pales. On the third, the Vector enters the gyroscope as a fourth, dim mark, and the Sovereign's Marks flare arterial crimson. At that instant, every Ash Mark belonging to the victim's household ignites — the family does not feel the extraction, only sees its announcement.

The Lapse — Completion

No fall, no wound, no cry. The body stands a long, wrong moment, mid-instruction with nowhere left to go, before the subject's own Ash Mark ignites arterial crimson at the wrist and stays lit. Entropy — held at bay for a lifetime by the forward pressure of will — rushes in all at once: skin tightens, hands curl, decades of unspent time cash themselves out against the flesh in the space of a few breaths. The subject cannot will resistance; the will was the vector, and the vector is now a mark spinning in a staff. They become a static echo — a Lapsed Form, chronologically stranded, aging into stillness, not yet a corpse until incapable of any meaningful decay. Until that point, it is an unfinished rendering.

The Scribae Vectorum add the Ledger's final line — "The subject has arrived." Only then is the extraction legally complete.

Disposition:

Honored/willing subjects are seated in the Hall of Lapsed Hours, tended forever by the Cultores.

Coerced and deceived subjects are given to the Aedilis Sanguinis or a Feudatory's house, or kept as furniture — taught, without irony, as mercy, since a Vorifex-taken vector retains its form.

High-value subjects may be held in private vaults as calibrated reservoirs for relic experimentation.

Failed or unknown subjects are removed without inscription.

The Field Harvest — The Private Taking

The Fractae require no hall, Ledger, or witness. The vector is not wound — it is snapped, spent instantly rather than stored. The subject receives no clean lapse but a jagged one: they rot forward, piecemeal, one limb at a time, as the severed thread whips back into the flesh. Left in the field or at their own threshold, as litter — because litter is what the left hand leaves. The Exactorii call it the Cut and do not speak of it at the feasts.

Public and Private Renderings

Public extractions discipline a population, reward the hierarchy, and display direct authority — architectural spectacles, silent but for the sudden ignition of the marks. Private extractions, in the lower vaults, serve intelligence, punishment, research, and politically inconvenient subjects, with no audience beyond necessary Order members — considered more complete, not less, since no witness dilutes the act.

Both forms are recorded under the same legal phrase: the Vector was collected.

Final Doctrine

The Inanifexate does not claim the victim gives their life. It claims something colder: the victim gives the next moment.

The future is not sacred because it is free. The future is valuable because it can be seized.

IX. Relics & Vestments

The Inanifex Gorget Rigid, high-necked collar forged from polished platinum, lined internally with soft deep crimson silk. Ergonomically frames the throat and jawline; serves as high-status armor while keeping the forehead fully visible to display the Sovereign's Mark.

The Fracturing Seal Heavy signet ring forged from white-gold, with a flat, polished obsidian face. The Sovereign's Mark is etched deep into the obsidian and filled with red channels. Used to stamp official decrees into hot crimson wax.

The Exhaurim Vestments Heavy, flowing robes of rich crushed crimson velvet, joined and framed by structured, polished platinum seam-panels. Small, smooth cabochon Fire Agates are set at even intervals along the platinum seams — their dark chalcedony matrix reveals three-dimensional, metallic flashes of bronze-gold and vivid orange fire that shift as the wearer moves.

Vorifex (The Staff) — formerly Siphon Ferula A commanding, tall shaft carved from polished pale ivory, inlaid with silver geometric filigree. Its apex mechanism, the Siphon Gyroscope, is a triple-tiered platinum cradle holding a miniature black hole singularity that bends ambient light. Three ruby-red Sovereign's Marks orbit the core independently at offset angles, forming a spinning, multi-axis gyroscope wrapped in a swirling aura of pitch-black power and arcing silver light. It is the instrument through which the Vital Vector is extracted.

The Fractae (Lesser Staffs) Struck from the same pale ivory as Vorifex, but set with a cold silver shard in a two-tier cradle rather than a singularity. Carried by the Exactorii for field work; sever rather than extract whole.

X. Visual Direction

The visual style bridges two distinct generation pathways:

Archaic Grandeur — heavily formalized medieval illuminated manuscripts depicting the Sovereign enshrined within the Iron Decrees.

Hyper-Real Imposing Realism — a living dark messiah manifesting in full regalia.

Across both mediums, the color discipline remains unyielding: arterial crimson, dead-gloss obsidian, sterile platinum, flawless pale ivory, cold-emitting silver light, punctuated by the bronze-gold and orange fire of the agates. Warmth, benevolence, and pastoral softness are rejected throughout.

XI. The Iron Decrees (The Tome) — Reserved for Last

Moved to the end of the codex per your instruction — to be fleshed out once the rest of the canon below it is locked, drawing on everything established above.

Material & Structure: A massive ritual tome bound in cold-forged iron plates over crimson leather. Houses medieval-style illuminated manuscript depictions of the Sovereign. Inlaid with geometric channels that hum and pulse with a faint, cold silver light when activated.

Established role so far: Sole authority to inscribe or amend it belongs to the Custos Doctrinae (Seat II of the Inanifexacy). It is read from at every Silent Convocation. It describes the Reversion as the highest honor the Inanifexate can bestow, and records the honored dead as monuments rather than losses.

Still open (the actual laws, prophecies, and doctrines written inside — what it commands, promises, and forbids) — reserved for the next piece of work, as planned.

Appendix: Locked Canon at a Glance

Empire/cult: The Inanifexate · Governing body: The Inanifexacy (Nine Seats) · Apex sovereign: The Inanifex

Sigil: The Sovereign's Mark (jagged lightning bolt) · Siphoned essence: The Vital Vector

Instruments: Vorifex (whole, public, holy) / the Fractae (partial, private, "the Cut")

Relics: The Inanifex Gorget, The Fracturing Seal, The Exhaurim Vestments, Vorifex, The Iron Decrees

Palette: Deep Crimson, Polished Platinum, Obsidian Black, Pale Ivory, Cold Silver, Fire Agate flashes

Nine Offices: Primus Exactor, Custos Doctrinae, Magister Vectorum, Praefectus Silenti, Aedilis Sanguinis, Faber Reliquiarum, Argentarius Inanifexis, Nuntius Exterior, Vox Inanifexis

Seven Orders: Exactorii, Silenti, Scribae Vectorum, Legati, Reliquarii, Nutritores, Cultores Inanifexis

Seven Grades: Feudatories, Benefacti, Vocati, Branded, Tolerated, Ledger-Born, Unentered

Mark renditions: Burning (Inanifex) → Dull (the Nine) → Blood-Bronze (Feudatories) → Iron (Orders) → Ash (Vocati/Branded) → Cinder (Benefacti)

Modes of consent: The Reversion (willing) · The Tithe-Rendering (coerced contract) · The Harvest/the Cut (deceived or field-taken)

Key rites: The Silent Convocation, The Binding of the Shard, The Threshold Rite, The Striking, The Lapse

Litany: "Quod fuit, cessat." — "What was, ceases."

