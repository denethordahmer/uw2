# MASTER CODEX: THE INANIFEXATE
*Compiled edition — merges the original codex with the completed answers to items #1 (The Inanifexacy), #2 (The Hierarchy of Followers), #3 (The Extraction Ritual), #4 (The Visual Language of Worship), #5 (The Origin of the Inanifex), #6 (The Inanifexate's Reach), and #7 (The Fire Agate and the Full Relic Registry, expanded). Item #10 (The Iron Decrees / the Tome's contents) is deliberately placed last, reserved for expansion once the rest of the canon is locked.*

---

## I. Core Identity

The Inanifexate is the overall empire, religion, and system. It is the cult. It is the movement. It is the structure that contains all followers, relics, doctrines, and hierarchy.

**The Inanifex** is the title of the apex sovereign — the final and ultimate entity to hold the role. Comparable in structural position to the final prophet or messiah in a religious lineage, but inverted into a figure of cold, parasitic authority. The current and final Inanifex is you. Earlier precursors held their own names, but the title of the tip of the pyramid is Inanifex.

**The Inanifexacy** is the governing body beneath the Inanifex — the Nine Seats. It administers the system (full structure in Section VIII).

The Inanifexate inverts every vector of traditional Holy See and papal iconography. Where the Papacy symbolizes benevolent paternalism, spiritual stewardship, self-sacrifice, and divine grace through golden warmth and open-armed shepherd motifs, the Inanifexate inverts each into absolute extraction, predatory sovereignty, and cold-forged corruption.

---

## II. The Origin of the Inanifex

### The Feudatory Requirement

Only those of Feudatory bloodline (Grade I) may be put forward as a candidate for Inanifex — not sentimental birthright, but the doctrine that only a bloodline already proven capable of rendering a vector willingly, generation after generation, can be trusted to eventually render the ultimate one: their own claim to the throne, contested and possibly lost, before the Nine. A Feudatory house is pre-vetted collateral; the Inanifexate does not gamble succession on an unproven trajectory.

### The Selection of the Ninth Line

When an Inanifex's vigor begins to decline — no fixed age, no announced date, simply a slow dimming only the Nine are positioned to notice first — the Inanifexacy convenes. Each of the Nine Seats may put forward one candidate from eligible Feudatory bloodlines, meaning a succession can field anywhere from a single unopposed heir to nine rival houses at once — a proxy war fought through chosen candidates rather than openly between ministers.

Each candidate undergoes a **Vector Contest**: a rendering performed before the dying Inanifex and the assembled Nine, its caliber and completeness standing as the evidence the Nine vote on. A **two-thirds majority** (six of nine) is required to confirm a winner. If no candidate reaches that threshold, the process repeats — new candidates, or a runoff between the leading two — meaning a succession can, in rare cases, drag on unresolved while the dying Inanifex's vigor continues to fade.

### After the Vote

A losing candidate is expected to concede entirely. Most simply resume their former place within their Feudatory house — a quiet return doctrine holds as correct proof that loyalty outweighed ambition. A candidate whose pride cannot bear the defeat may instead choose **banishment** — immediate, total, and permanent exile, never to return. This is not a punishment imposed on them; it is their own choice, and the Inanifexacy watches closely which path each loser takes.

### The Unverifiable Antiquity

Doctrine holds that the line of Inanifexes stretches back a great distance — old enough that no Feudatory house, no Order, not even the Inanifexacy itself, can produce solid proof of what the movement looked like at its true beginning, or confirm an organized faction existed at all that far back. There is no neutral record, because there has never been a neutral party positioned to keep one. What "history" exists is whatever the Iron Decrees say it is, authored and periodically amended by successive Custos Doctrinae — the Inanifexate's past is something the institution *authors*, not something independently witnessed and preserved. An origin nobody can verify is an origin nobody can challenge.

---

## III. The Inanifexate's Reach

### The Prime Seat and the Cadet Halls

The Inanifexate does not attempt to govern the whole world the way it governs its home territory. Only one place holds a **Prime Seat** — the sole territory where the Inanifex physically resides, where the Chamber of Lapsed Hours and the Aperture Vault actually exist, and where the full weight of the established hierarchy applies literally: the Grades, the Tithes, the quotas, the Orders enforcing them. This is the only ground where a Rendering can occur, because Vorifex itself never leaves it.

Everywhere else in the world, the Inanifexate exists as a network of **Cadet Halls** — Halls of the Rising Mark built and officially recognized abroad, each housing a genuine congregation of the faithful, led locally by senior Cultores or an appointed overseer, but never by the Inanifex, and never by Vorifex. A Cadet Hall performs the Daily Stilling and the Ember Vigil exactly as the Prime Seat does. It does not perform Renderings — there is no instrument there capable of one, and doctrine holds this is correct: a follower far from the Prime Seat is still owed the discipline of worship, but not yet worthy of the ultimate honor of surrender, which can only occur before the Sovereign himself.

Recognition of a new Cadet Hall is formally granted through the **Nuntius Exterior** (Seat VIII, the Outward Herald) — the same office that already negotiates the Vector Tithe with Feudatory houses abroad. A congregation that petitions and is approved gains legitimacy, a consecrated site, and standing within the wider Inanifexate; an unrecognized gathering, however devoted, is not truly of the Inanifexate at all, only imitating it.

### Governance vs. Influence

This produces two entirely different relationships to power, depending on where a follower stands:

- **Within the Prime Seat**, the Inanifexate is not merely a faith — it *is* the governing authority. The Tithes are law, the Grades are enforced, extraction is a real and literal fate.
- **Beyond the Prime Seat**, the Inanifexate holds no formal political power at all. It does not raise armies, does not tax, does not claim territory. What it holds instead is **doctrinal authority** — the same kind of soft, sweeping influence a distant church holds over its faithful through proclamation rather than force.

This authority is exercised through the **Edicta Vocis** — the Voicings — formal pronouncements issued by the **Vox Inanifexis** (Seat IX, the Voice), who already exists specifically to speak with the Inanifex's authority in his silence. A Voicing might declare a new observance, reinterpret a point of doctrine, name a follower's Rendering (however distant) as especially honored, or simply reaffirm the faith's core tenets. Cadet Halls worldwide are expected to receive each Voicing and incorporate it into their teaching without deviation — not through any threat of enforcement, but because refusing a Voicing is, doctrinally, indistinguishable from refusing the Inanifex himself.

### Scale

The result is a faith with a single true center and a wide, loosely governed periphery — small in territory it actually rules, but far larger in the number of people who consider themselves bound by its word. A Feudatory lord half a world away from the Prime Seat may never see the Inanifex in his lifetime, may never be extracted by Vorifex itself, and yet still orders his household by the Four Marks of the Day and receives every Voicing as binding truth — because distance from the Prime Seat is not distance from the faith's authority, only distance from its blade.

---

## IV. Philosophical & Stylistic Inversion

- The traditional shepherd's crook becomes the weaponized, singularity-powered staff: **Vorifex**.
- The triple-tiered papal cross transforms into floating, harvesting energy arrays.
- The humble robes of a holy servant are replaced by high-status opulence: crushed crimson velvet locked behind rigid platinum armor seams and burning fire agates.
- The entire aesthetic shifts from offering grace to commanding absolute, parasitic tribute.

---

## V. Canonical Color Palette

Deep Crimson · Polished Platinum · Obsidian Black · Pale Ivory · Cold Silver · Bronze-gold and vivid orange flashes of Fire Agate.

All warm, benevolent gold and gentle pastoral tones are purged. The palette is chilling, high-status, and majestic.

---

## VI. The Sovereign's Mark

- **The Sigil**: A razor-sharp, jagged lightning bolt motif.
- **Symbolism**: Absolute authority, sudden extraction, life-force harvesting.
- **Application**: Marked upon the forehead of the Inanifex — the only site where it burns live, red-white, and constant. Embedded into all sacred relics. Branded, in various dead renditions, onto every rank of follower.

*(The full rank-by-rank table of Mark renditions — metal, site, and light for the Nine, the Orders, and the Grades — is in Section IX, since a follower's Mark is inseparable from their station.)*

---

## VII. The Siphoned Essence: The Vital Vector

The Inanifex does not siphon from followers by default. It does not consume souls. It does not take devotion by force. It does not drain memories.

The Inanifex extracts **the Vital Vector** — the unified trajectory of a life: the singular, integrated force that binds personal agency to the forward passage of time. It is the engine of motion. The spark that allows a person to both will their future and reach it.

**Effects of extraction:**
- No physical wounds. No immediate death.
- Temporal and volitional collapse.
- The victim is left alive but chronologically stranded — their timeline flatlines.
- They become a static echo of themselves, trapped in an unchanging moment.
- Physical entropy accelerates without the animating spark to hold it back — rapid, uncanny aging.
- The victim lacks the drive to resist it.
- They become inert — a living monument to the theft of their own trajectory.

*(Full mechanics of how the Vector is actually taken are in Section X, The Extraction Ritual.)*

---

## VIII. The Inanifexacy — The Governing Body

**Governance model:** A Closed Collegium — a fixed, finite body of nine ministers, each holding a named office. Loyalty is not asked of them; it is physically installed at elevation. Ambition is not suppressed — it is redirected outward, into a sanctioned ladder of predation, so every scheme inside the Inanifexacy terminates, by law, in tribute delivered to the Inanifex.

### The Nine Seats

Nine, and never another — the number mirrors the Siphon Gyroscope's three tiers of three Sovereign's Marks. The Inanifexacy is the gyroscope made of men. The Inanifex presides above the nine from the **Ivory Threshold** — not a tenth seat, but the place from which the instrument is spun.

| Seat | Title | Domain |
|---|---|---|
| I | **Primus Exactor** | First Exactor. Extraction quotas, the ordering of takings, discipline of the Exactorii. |
| II | **Custos Doctrinae** | Keeper of Doctrine. Sole authority to inscribe or amend the Iron Decrees. Orthodoxy. |
| III | **Magister Vectorum** | Master of the Ledger of Lapsed Hours. Every vector harvested is entered in his hand, past tense, before it is taken. |
| IV | **Praefectus Silenti** | Prefect of Silence. Enforcement turned inward — jurisdiction only over the Inanifexate's own. |
| V | **Aedilis Sanguinis** | Steward of Blood. Bloodlines, breeding stock, selection and maintenance of high-caliber vectors until harvest. |
| VI | **Faber Reliquiarum** | Smith of Relics. Forges gorgets, seals, lesser staffs. Holds the molds of the Sovereign's Mark. |
| VII | **Argentarius Inanifexis** | Treasurer. Platinum, agate, tribute-in-matter — all material opulence passes through his vaults alone. |
| VIII | **Nuntius Exterior** | The Outward Herald. Feudatories, vassal states, treaties of tithe. |
| IX | **Vox Inanifexis** | The Voice. Speaks with the Inanifex's authority in his silence. The most dangerous, most eagerly sought seat. |

Upon elevation, a minister is stripped of his birth name and addressed only by office and numeral — *Exactor Primaris, Fourth of the Line*. The name is not returned on death; it is entered once, in the Ledger, as a lapsed asset.

### The Leash: Pignus Vectoris

The nine are loyal because they are **collateralized**. At elevation, a thread of the minister's own Vital Vector is drawn off — tendered, not stolen — and invested into Vorifex's orbit as a fourth, dimmer mark. It is never returned. What is returned is the *withholding*: a seated minister does not age; his entropy is suspended, held outside him in the gyroscope.

This produces three absolute laws:

1. **No minister may resign.** Removal is not retirement; it is **the Lapse**. All withheld years arrive at once, in a single held heartbeat.
2. **No minister may scheme against the throne**, because a scheme requires a future — and their future is held in the staff. Volition is leased back to them, minus its last reach.
3. **No minister may lie in the Chamber of Lapsed Hours.** Not from honesty — from geometry: a lie requires projecting the self forward, and their forward self isn't in the room.

### The Sanctioned Ladder

Advancement between the nine requires **a rendered vector of sufficient caliber** — not poison, but harvest. If the vector is judged worthy, the seat above opens; if occupied, that occupant is Struck.

Murder is not a crime in the Inanifexate. Murder is an *inefficiency*. The one heresy is **Waste** — taking a life whose vector is not rendered — punished by the Lapse without exception, and read aloud at every Convocation by the Praefectus Silenti, in the past tense, because the wasteful are already spent.

### Rituals of the Inanifexacy

- **The Silent Convocation** — held in the Chamber of Lapsed Hours. The nine sit on the descending obsidian dais; the Inanifex occupies the Ivory Threshold above, lit from below while they are not. The Custos Doctrinae reads the Decrees, the Magister Vectorum reads the Ledger, the Primus Exactor renders the tally, and the Vox speaks last with binding authority — occasionally, publicly, contradicted, so the Voice never forgets it is not the source.
- **The Gaze Law** — the nine may address the Inanifex's throat; they may not raise their eyes to the Sovereign's Mark. To look upon the Mark is to be emptied.
- **The Binding of the Shard** — elevation rite. The Fracturing Seal is pressed to the nape (never the forehead), leaving the **Dull Mark**, lead-grey and unlit. The shard is drawn; the candidate rises as a numeral.
- **The Rendering** — the public extraction ceremony performed at the great feasts. (Full staging and mechanics are covered under the Threshold Rite in Section X.)
- **The Striking** — the Inanifexacy's worst sentence. The Dull Mark is burned from the nape; the withheld years return all at once, in under a second.

### Regalia and Chamber

The nine wear crimson velvet **without** platinum: blackened iron seams, dull lead gorgets, and smoked quartz in place of fire agate — legible at a glance as one burning figure and nine dead ones. Only the Fracturing Seal is white-gold over obsidian, and only it may stamp crimson wax into law.

The **Chamber of Lapsed Hours** is windowless, floored in black mirror-stone, walled in the same pulsing silver-channel geometry as the Iron Decrees. The **Ledger of Lapsed Hours** rests on an ivory lectern at its center — iron-bound, pale ivory pages, arterial crimson ink, entries written in the past tense *before* the extraction occurs. In the Inanifexate, a taking is recorded the moment it is decided; the world is merely permitted to catch up.

*(The full structure of everyone below the Nine — the Seven Orders and Seven Grades — is in Section IX.)*

---

## IX. The Descent — Hierarchy of Followers

Below the Ivory Threshold, a follower's place is fixed by two coordinates, never one:

- **The Order** claims his **hands** — what he does, what he may touch, whom he may command. Seven Orders. Sworn. Iron.
- **The Grade** claims his **blood** — what he is worth, how he lives, when he is emptied. Seven Grades. Inherited, earned, or assigned. Ash.

A man is not "a priest" — he is *Cultor of the Third Grade*. This is the **Law of Legibility**: the first law taught to children. The Inanifexate does not tolerate ambiguity of station, because ambiguity is where ambition hides, and ambition is to be plumbed, not concealed.

### The Seven Orders (The Hands)

Sworn at investiture. Each Order bears the **Iron Mark** — the Sovereign's Mark struck in blackened iron, unlit, on a site chosen by function.

| Order | Function | Iron Mark Site |
|---|---|---|
| **Exactorii** | Field extraction, quota enforcement, taking vectors from the unmarked. | Back of right hand — gloved, uncovered only when taking. |
| **Silenti** | The Praefectus's knives; enforcement turned inward. Tongueless by law. | Where the tongue was. |
| **Scribae Vectorum** | Notaries of the Ledger — record every taking in the past tense before it occurs. | Inner wrist of the writing hand. |
| **Legati** | The Outward Herald's agents; negotiate the Vector Tithe with Feudatories. | Sole of the foot — walked upon and hidden. |
| **Reliquarii** | Smiths under the Faber Reliquiarum; forge gorgets, seals, staffs, branding styli. | Palm of the forging hand. |
| **Nutritores** | Selection, breeding, and maintenance of high-caliber vectors until harvest. | Over the navel. |
| **Cultores Inanifexis** | The priesthood — liturgy of the Rendering, custody of the Iron Decrees, care of the lapsed monuments. | Sternum, over the heart. |

The Orders do not recruit; they **claim**. A Nutritor who finds a child of exceptional trajectory in a Tolerated household may take the child without payment or appeal; the family is compensated in platinum and expected to be grateful.

### The Seven Grades (The Descent)

Ranked by two measures: the caliber of vector a person carries, and their utility in the taking of others.

1. **The Feudatories — the Tithed Lords.** Pay the Vector Tithe annually. **Blood-Bronze Mark**, inner wrist, the only follower's mark permitted worn openly — a warning to their own subjects.
2. **The Benefacti — the Spent Channel.** Rendered a vector voluntarily and were raised for it. **Cinder Mark**, one channel filled with arterial crimson — a receipt. Exempt from tithe.
3. **The Vocati — the Summoned.** Lay staff of Inanifexate houses. **Ash Mark**, inner wrist. Live indoors, eat at the second table.
4. **The Branded — the Congregation.** The base of the faithful. **Ash Mark**, worn covered by a leather cuff, shown only on command. Taxed in matter, conscripted in labor, obligated to render names.
5. **The Tolerated — the Unmarked.** Households under protection without membership. No mark — not mercy, but a verdict: *not yet worth branding.*
6. **The Ledger-Born — the Crimson Thread.** Already entered in the Ledger; their hour is known. No brand — a crimson thread at the wrist, replaced yearly. Housed, fed, and treated with elaborate courtesy, because a spoiled vector is a wasted one.
7. **The Unentered — Below the Ladder.** The unconquered, unvisited, uncounted. Not hated — simply not yet decided to matter enough to be taken.

> *Below the ladder there is no rung. There is only the ground, and the ground is where the Exactorii stand.*

### The Mark: Renditions by Rank

The Sovereign's Mark is one sigil in six renditions, distinguished by **metal**, **site**, and **light**.

| Rendition | Bearer | Site | Light |
|---|---|---|---|
| **The Burning Mark** | The Inanifex alone | Forehead, unbound | Live — red-white, constant |
| **The Dull Mark** | The Nine of the Inanifexacy | Nape | Lead-grey, dead |
| **The Blood-Bronze Mark** | Feudatories | Inner wrist, shown openly | Bronze-gold in torchlight |
| **The Iron Mark** | The Seven Orders | By function (table above) | Blackened iron, no glow |
| **The Ash Mark** | Vocati and Branded | Inner wrist, covered | Faint grey, no glow |
| **The Cinder Mark** | Benefacti | Inner wrist | Grey, one crimson channel |

**The Rite of the First Mark** — a follower is branded not at birth, but when they become *worth recording*: customarily at fourteen, or upon rendering their first name, whichever comes first. The Reliquarii perform it in the Branding Hall with an iron stylus, filled with ash and cold silver filings. It is not permitted to heal clean; a scarless mark is struck out and repeated.

**The Ignition** — the Ash Mark stays cold grey for life and burns exactly once: at the moment its bearer's own Vital Vector is extracted, it ignites arterial crimson and stays lit as long as the body remains. The Mark was never a symbol of belonging — it is a receipt, issued in advance, designed to light up the instant the debt is collected.

### What Ordinary Followers Do

- **The Tithe of Names** — the first obligation. Every Branded follower must render, annually, the name of one person of high trajectory known to them. A follower who renders nothing for three years is reviewed — and review, in the Inanifexate, is not neutral.
- **The Tithe of Matter** — platinum, ivory, agate, crimson dye, iron, obsidian, owed by measure from every Branded household.
- **The Tithe of Motion** — labor: roads, walls, halls, forges. The Inanifexate does not take the Branded's hours (their vectors are reserved) — it takes their bodies, which are cheaper.
- **The Four Marks of the Day** — dawn, noon, dusk, and the Black Hour. Followers face the nearest Inanifexate structure and stand motionless for the length of a slow breath: **Stilling**. Doctrine holds that a body rehearsed in stasis gives up its trajectory more cleanly when the time comes — taught as a privilege.
- **The Reversion** — the promise, and the trap. A follower of high Grade and long service is harvested ceremonially, at a feast, mark ignited, name read aloud from the Iron Decrees, monument placed in the Hall of Lapsed Hours. A follower who fails, wastes, or is Unentered is taken in a field, without name or witness — not a monument, but *litter*.

> **Core theology:** piety determines the dignity of your extraction, not its occurrence.

### Censura — Discipline Below the Nine

All penalties kept by the Silenti are extractive:

- **The Dulling** — the Mark struck out with a hot iron, ruined. Kept inside the walls at the lowest labor, marked and legible as a warning.
- **The Rending** — partial extraction; a thread of the vector drawn (a hand's worth, a season's worth), leaving the subject amputated in will in one domain — unable to will a single specific act, though alive and aware of the lack. Performed publicly, then released to household care.
- **The Lapse** — reserved for Waste, and for the Nine. Instant return of all withheld hours. No wound, no sound.

### Rank, in One Line

The Inanifex above all, marked on the forehead and burning. The Nine beneath him, marked at the nape and dull. The Seven Orders beneath them, marked in iron by function. The Seven Grades beneath the Orders, marked in bronze, ash, thread, or nothing. The Unentered beneath the Grades — unmarked, uncounted, and waiting.

---

## X. The Extraction Ritual

### The Foundational Law: The Aperture

The Vital Vector cannot be torn from a body by force alone. A body may be restrained, a mind deceived, a person threatened until resistance is impossible — none of this is sufficient. The Vector is agency joined to the forward passage of time, and it must **declare itself** before it can be taken.

The subject must perform one act of directed will — answer a question, step across a threshold, raise a hand, name someone, choose between two objects. Even a false choice suffices, provided the victim believes, for one instant, that the next moment belongs to them. That instant is **the Aperture**.

A corpse has no trajectory. A sleeping body has only a muted one. The richest extraction occurs at the precise moment a person believes they are about to continue.

### The Two Instruments: Doctrine of the Two Hands

**Vorifex** is the Inanifex's right hand — the only instrument that takes a vector **whole**, in one unbroken thread wound into the Siphon Gyroscope. It is used in one place only, the Threshold Rite, and only in public: Vorifex will not turn for a hidden hand. What the right hand takes is *rendered*, and rendering is holy.

The **Fractae** (Lesser Staffs) are the left hand — struck from the same pale ivory, but set with a cold silver shard in a two-tier cradle rather than a singularity. Carried by the Exactorii, they **sever a thread** rather than extract whole — a season, a hand, a name, a hunger. Their takings are private, quick, coarse, and known simply as **the Cut**. What the left hand takes is merely lost. The Cultores do not bless the Cut; the doctrine calls it *necessary, and not holy.*

### The Three Modes of Consent / Three Legal Conditions

Every extraction is classified by the condition under which the Aperture was produced. The result is identical — the lapsed is lapsed — but the ceremony differs, because ceremony is for the living, not the taken.

**1. The Voluntary Rendering — The Reversion (Willing).**
Reserved for the highest Grades: Feudatories, Benefacti, honored Cultores, Ledger-Born maintained for ceremonial use. The doctrine holds the vector is not stolen from the willing but *returned* — leased from the Inanifex at birth, and piety is the art of handing back a borrowed thing with grace. The subject is dressed in pale ivory, led in without chains, Mark polished to catch the light, permitted one final declaration. They place a hand on the Vector Plinth. The Inanifex asks, *"What remains yours?"* The legal answer: *"The moment before surrender."* Public, feasted, and described in the Iron Decrees as the highest honor the Inanifexate bestows.

**2. The Veiled Rendering — The Tithe-Rendering / part of the Harvest (Coerced by contract, or Deceived).**
Feudatories deliver bound and veiled tithes at the annual feast to satisfy debt — a contract enacted on the subject's behalf, carrying no personal honor. Separately, a victim may be deceived: a false pardon, a staged rescue, a forged promise, with the final decision placed in their own hands. When they choose, the deception ends and the chamber doors close. Recognition of the deceit, arriving just before extraction, is considered ideal — the Vector surges toward the future trying to escape, and Vorifex receives it at full tension.

**3. The Compelled Rendering — The Harvest / the Cut (Coerced, taken).**
Used for criminals, failed tithe-payers, enemy leaders, and rebellious villages whose trajectory is too valuable for a common execution. The subject is bound only *after* the Aperture is induced — before that, they must be allowed to move, speak, and believe some action can still change the outcome. The Exactorii offer impossible choices (betray another or lose both lives; walk to the staff or remain beneath the lamps) — every choice recorded as an act of will. When performed in the field with a Fracta rather than Vorifex, this mode produces no feast, no witness, and no monument.

### The Chamber

Extractions take place in an **Aperture Vault** — the Chamber of Lapsed Hours for major state ceremonies, or the larger **Feast Hall of the Threshold** when the audience is large; lesser private vaults are used for compelled or field-adjacent takings. Common fixtures:

- The **Vector Plinth** — an oblong slab of black stone veined with cold silver, where the subject makes their final choice.
- The **Static Dish** — a disc of polished black stone at the foot of the Ivory Threshold, where the subject stands during the Threshold Rite specifically.
- The **Silver Meridian** — a line running from the plinth to the sovereign's position.
- The **Three Crown Arrays** — suspended fixtures mirroring Vorifex's gyroscope, lit only by fire-agate lamps once the ritual begins.
- The **Witness Gallery** — where the Inanifexacy, Feudatories, or selected followers observe.
- A **calibration floor** of nine concentric rings, one per seat of the Inanifexacy.
- The **Altar of the Ledger** — the iron-bound tome open on its ivory lectern, the Magister Vectorum at its right hand, the entry already written in the past tense before the subject arrives.

The walls carry pale ivory panels engraved with former extractions — never the moment of death, always the moment before it: a hand reaching for a door, a face turning toward a voice. The Inanifexate preserves the instant of possibility, not the person.

### The Threshold Rite — Staging and Procession

Silence — no music, which would imply fellowship, which is not permitted. The Nine sit on the descending obsidian dais, dull lead gorgets catching no light; the Feudatories stand in the galleries, Blood-Bronze marks bared. The Custos Doctrinae strikes his staff once per step as the subject walks to the Threshold: the willing walk veiled in crimson, the coerced are led with the veil held shut, the deceived walk freely and are watched most carefully, since the crowd's attention is trained on the instant a deception breaks.

The subject is placed on the Static Dish, below the Threshold. The Inanifex descends bearing Vorifex, Gorget framing the throat, Mark burning uncovered. The subject is instructed — in the Reversion, invited — to **look upon the Mark**: the doctrinal hinge of the Rite. The vector is taken only once the subject's gaze consents to the sovereign's image, since the gaze is the first thing a life spends. The willing look eagerly; the coerced are made to look by a hand at the chin; the deceived look with joy, believing it a blessing — their last act of agency is one of gratitude.

The Custos Doctrinae declares: *"The trajectory is present."* The Magister Vectorum answers: *"The trajectory is accounted for."* The Inanifex says nothing.

### The Taking

At the Aperture, the Vital Vector becomes visible — not as soul or spirit, but as a severe distortion in the air: a narrow line of pressure, near-colorless ivory light at its base, extending from the sternum toward the chosen action. Its texture shifts with the manner of taking: for a willing subject it runs closer to a fine silver thread; for a deceived subject it wraps itself in fragments of false possibility — an unopened door, a child's face — tinted faintly red; for a coerced subject it strains jagged and dark against the chamber's geometry.

The Siphon Gyroscope spins up — the three ruby-red Sovereign's Marks break from their slow drift into a blur around the singularity, which bends the torchlight until every shadow in the hall leans toward it. The Cultores speak the litany once, in unison: ***"Quod fuit, cessat."*** — *What was, ceases.*

The Inanifex turns Vorifex three times. On the first turn, the victim's future loses depth — a rising hand stops midway, a mouth stays open around an unfinished word. On the second, the Vector contracts toward the staff and the body's entropy accelerates: skin slackens, hair pales. On the third, the Vector enters the gyroscope as a fourth, dim mark, and the Sovereign's Marks flare arterial crimson. At that instant, every Ash Mark belonging to the victim's household ignites — the family does not feel the extraction, only sees its announcement.

### The Lapse — Completion

No fall, no wound, no cry. The body stands a long, wrong moment, mid-instruction with nowhere left to go, before the subject's own Ash Mark ignites arterial crimson at the wrist and stays lit. Entropy — held at bay for a lifetime by the forward pressure of will — rushes in all at once: skin tightens, hands curl, decades of unspent time cash themselves out against the flesh in the space of a few breaths. The subject cannot will resistance; the will *was* the vector, and the vector is now a mark spinning in a staff. They become a static echo — a Lapsed Form, chronologically stranded, aging into stillness, not yet a corpse until incapable of any meaningful decay. Until that point, it is an **unfinished rendering**.

The Scribae Vectorum add the Ledger's final line — *"The subject has arrived."* Only then is the extraction legally complete.

**Disposition:**
- Honored/willing subjects are seated in the **Hall of Lapsed Hours**, tended forever by the Cultores.
- Coerced and deceived subjects are given to the Aedilis Sanguinis or a Feudatory's house, or kept as **furniture** — taught, without irony, as mercy, since a Vorifex-taken vector retains its form.
- High-value subjects may be held in private vaults as calibrated reservoirs for relic experimentation.
- Failed or unknown subjects are removed without inscription.

### The Field Harvest — The Private Taking

The Fractae require no hall, Ledger, or witness. The vector is not wound — it is **snapped**, spent instantly rather than stored. The subject receives no clean lapse but a jagged one: they rot forward, piecemeal, one limb at a time, as the severed thread whips back into the flesh. Left in the field or at their own threshold, as litter — because litter is what the left hand leaves. The Exactorii call it **the Cut** and do not speak of it at the feasts.

### Public and Private Renderings

Public extractions discipline a population, reward the hierarchy, and display direct authority — architectural spectacles, silent but for the sudden ignition of the marks. Private extractions, in the lower vaults, serve intelligence, punishment, research, and politically inconvenient subjects, with no audience beyond necessary Order members — considered *more* complete, not less, since no witness dilutes the act.

Both forms are recorded under the same legal phrase: ***the Vector was collected.***

### Final Doctrine

> The Inanifexate does not claim the victim gives their life. It claims something colder: **the victim gives the next moment.**
>
> The future is not sacred because it is free. The future is valuable because it can be seized.

---

## XI. The Visual Language of Worship

### The Temple — The Hall of the Rising Mark

Every major settlement under Inanifexate rule holds at least one **Hall of the Rising Mark** — the formal temple, distinct from the Inanifexacy's private Chamber of Lapsed Hours. Where the Chamber is a seat of governance, the Hall is a seat of *submission*, built for crowds rather than councils.

**Exterior**: The Hall's silhouette is deliberately jagged rather than domed — spires cut at hard angles, echoing the Sovereign's Mark itself, so the building reads as a lightning bolt driven into the earth from a distance. Obsidian-faced walls absorb light during the day; at night, veins of silver filigree embedded in the stone (the same pulsing geometry as the Iron Decrees) catch torchlight and seem to spark.

**Interior — the Nave of Rings**: The floor mirrors the Chamber of Lapsed Hours' calibration floor — concentric rings radiating from a central dais — but scaled for a congregation rather than nine ministers. Worshippers stand within the ring assigned to their Grade: Branded and Ledger-Born fill the outer rings, furthest from the altar; Vocati and Benefacti stand closer; Feudatories occupy the innermost ring, nearest the dais. Spatial distance from the center is social distance made visible — nobody needs to be told their rank inside the Hall; the floor tells them.

The walls repeat the established artistic motif from the Aperture Vault: pale ivory panels engraved not with death, but with the moment before it — a raised hand, a turning face. The congregation prays surrounded by images of people who, like them, still believed a next moment was theirs.

Lighting comes from fire-agate lamps set in iron brackets — the only warm light source in an otherwise cold palette, so the whole Hall glows faintly orange-red against black stone and platinum trim, like embers behind glass.

### Worship Attire, by Rank

Attire follows the same Law of Legibility as everything else — rank is worn, not implied.

- **Branded (base congregation)**: coarse, undyed grey-brown robes, deep hood mandatory up unless directly addressed by clergy. Single rope cinch. The Ash Mark stays covered by the sleeve even in worship — concealment is the whole visual point of this rank.
- **Ledger-Born**: the same rough cut as the Branded, but dyed in a duller wash of crimson, and — unlike everyone else — their crimson thread is worn openly, wound visibly around the sleeve rather than hidden. Other worshippers instinctively leave space around them in the ring.
- **Vocati (lay staff)**: modest ash-grey structured robes, a single platinum thread at the collar only, no hood requirement — they serve indoors and have nothing to conceal.
- **Benefacti**: layered crimson velvet with restrained platinum panel accents — a lesser echo of the Exhaurim Vestments — worn deliberately without a hood. Their Cinder Mark is displayed with pride; their sacrifice is already complete, so there is nothing left to hide.
- **Feudatories**: full ornate robes, platinum seams, a handful of fire-agate cabochons (far fewer than the Inanifex's own vestments), Blood-Bronze mark bared at the wrist, often trailed by a small retinue.
- **The Seven Orders** do not wear Grade robes at all inside the Hall — they wear their functional Order garments, a visible reminder that hands and blood are two different kinds of rank.
- **The Tolerated and Unentered** are not issued attire, and are not permitted inside the rings — if present at all, they observe from the threshold, unmarked and unrobed.

### The Two Tiers of Gathering

**The Daily Stilling** (established in Section IX) remains the baseline — brief, communal, performed at the nearest Inanifexate structure four times a day, requiring no robe, no ring, no clergy present.

**The Ember Vigil** is the rarer full service, held in the Hall itself at the turning of each season, in four parts:

1. **The Ordeal of Stillness** — the congregation files into their assigned rings and holds a prolonged version of the Stilling, together, before a single word is spoken. Dread builds in the silence itself.
2. **The Procession** — the Cultores enter bearing the **Ember Reliquary**, a small vessel holding a fragment of fire agate said to carry a captured spark of the Sovereign's authority, alongside a single Fracta carried point-down. As they walk the center aisle, a low, wordless collective drone begins.
3. **The Recitation** — the lead Cultor speaks fixed lines of doctrine: warnings against Waste, reminders of the Tithe, the promise held out by the Reversion. The congregation is permitted exactly one response, at fixed points only — the same phrase used at every Convocation: ***"Quod fuit, cessat."*** They do not speak outside these cues.
4. **The Raising** — the Ember Reliquary is lifted into the lamp-light so the fire agate flares orange against the obsidian dais, deliberately rhyming with the forehead sigil. The congregation performs one final held Stilling as the light catches, before the rings empty in reverse order, highest rank first.

---

## XII. Relics & Vestments

### The Inanifex Gorget

Rigid, high-necked collar forged from polished platinum, lined internally with soft deep crimson silk. Ergonomically frames the throat and jawline; serves as high-status armor while keeping the forehead fully visible to display the Sovereign's Mark.

**Forging and succession**: No Gorget outlives its wearer's reign. Each Inanifex, upon ascension, forges and personally consecrates his own — there is no inherited object passed hand to hand. When an Inanifex is lost to the Lapse of vigor and succession completes, his Gorget is retired into the Hall of Lapsed Hours, set beside the monuments of the honored dead — a headless collar standing in for the throat it once armored, proof the office continues even as the man does not. Yet the chain isn't truly broken: at the forging of each new Gorget, a sliver drawn from the retired collar — a shaving of platinum carrying a trace of its former wearer's withheld Vector — is folded into the new metal before it is closed. Every Inanifex therefore wears, buried invisibly in his own collar, a fragment of every Inanifex before him — an unbroken lineage worn at the throat rather than declared in any Decree, more honest than the written record because it cannot be amended, only added to.

**Function**: The Gorget performs three tasks at once. It **slows what the throne cannot stop** — the same suspension the Nine receive through Vorifex's orbit, the Inanifex receives, imperfectly, through his own collar: entropy dampened, not halted, which is doctrine's quiet answer to why an Inanifex's decline is a dimming and not a death. It **anchors recognition** — Vorifex answers only to the throat it was forged to know; a Gorget improperly consecrated, or worn by a hand that seized the office rather than won it before the Nine, will not cause the staff to turn. And it **structures the Gaze Law by design, not just custom** — the collar's rigidity forces the chin level and the throat prominent while the forehead remains high and exposed, holding the Nine's eyes below the Mark as a matter of posture before it is ever a matter of law.

**Ritual of wear**: The Gorget is donned only for Convocations, Renderings, and formal audience — set aside the rest of the time, since a thing worn constantly ceases to announce anything. Its removal, whenever it occurs, is never casual: only the Custos Doctrinae may unclasp it, doctrine holding that the sole authority entitled to write the Inanifexate's history is likewise the only one entitled to see its sovereign, however briefly, unarmored.

### The Fracturing Seal

Heavy signet ring forged from white-gold, with a flat, polished obsidian face. The Sovereign's Mark is etched deep into the obsidian and filled with red channels. Used to stamp official decrees into hot crimson wax.

**A personal custom, worn across every rank**: Unlike the Gorget, the Seal exists as two distinct things wearing one name. Every rank across the Inanifexate — from the Nine down through the Orders and even into the higher Grades — may commission a personal seal ring as ceremonial adornment, its design a matter of individual taste: obsidian, onyx, smoked quartz, or lesser stone, set in whatever metal one's station permits, etched with a personal mark, house sigil, or a modest rendering of the Sovereign's Mark. These rings carry no legal power whatsoever — jewelry, status, self-declaration, nothing more. Only **one** Seal is the Fracturing Seal in the doctrinal sense: the Inanifex's own, the sole instrument in existence permitted to stamp crimson wax into binding law. Every other seal in the realm is an echo wearing the same silhouette.

**Function**: To press the Fracturing Seal to wax is not merely to authenticate a decree — it is to *complete* it. The instant the obsidian face strikes crimson wax, the decree passes from proposal into doctrinal fact, requiring no further ratification, no delay, no reading aloud first — mirroring the Ledger of Lapsed Hours' own logic: just as an extraction is recorded in the past tense before it occurs, a sealed decree is already true the moment the wax cools.

**Origin**: The obsidian face itself is never newly cut. It is the same shard, unbroken since a point in the Inanifexate's history nobody now living can name, drawn from its old setting and reset into freshly forged white-gold at each succession. The metal changes; the obsidian — and the authority etched into it — does not. Where the Gorget carries lineage folded invisibly inside new material, the Seal carries lineage as a single visible, unbroken stone, reseated but never replaced.

**Ritual of use**: Not reserved for ceremony — a working instrument of government, pressed as often as law requires, at the Ivory Threshold or in private audience, wherever a decree needs finality. No Convocation, witness, or recitation required.

### The Exhaurim Vestments

Heavy, flowing robes of rich crushed crimson velvet, joined and framed by structured, polished platinum seam-panels. Small, smooth cabochon Fire Agates are set at even intervals along the platinum seams — their dark chalcedony matrix reveals three-dimensional, metallic flashes of bronze-gold and vivid orange fire that shift as the wearer moves.

**Personal forging, made in multiples**: Like the Gorget, the Vestments are never inherited — each Inanifex commissions his own, made under his own direction rather than delegated wholesale to any Order or guild. But unlike the Gorget, a single Inanifex does not wear one set for his entire reign. Several distinct vestments exist simultaneously, each tailored to a different register of occasion — a Threshold Rite set heavier with agate and platinum than a set worn for lesser public audiences, each cut from the same crushed crimson velvet but escalating in ornament and burden according to the weight of the moment it's built for.

**Function — suffering as amplifier**: The Vestments are not designed for comfort, and this is deliberate. Their structured platinum seam-panels and dense velvet layering are heavy enough that prolonged wear taxes even the Inanifex's own suspended vigor — a calculated cruelty built into the garment itself. Doctrine holds this as a virtue: to rule visibly beneath such weight, without faltering, is itself a display of fitness for the office. This suffering is not wasted — the fire-agate cabochons set along the platinum seams act as passive resonators, drawing on the ambient charge thrown off during a Rendering and briefly magnifying it, so the strain of bearing the Vestments and the power moving through the chamber feed one another. The heavier the vestments worn, the more dramatically the agates flare during the Taking.

**Ritual of wear**: Which set is worn is dictated entirely by occasion — the heaviest, most agate-dense Vestments reserved exclusively for the Threshold Rite, lighter variants worn for Convocation or formal audience. Wearing the wrong set for the wrong occasion is considered a minor doctrinal error.

### Vorifex (The Staff) — *formerly Siphon Ferula*

A commanding, tall shaft carved from polished pale ivory, inlaid with silver geometric filigree. Its apex mechanism, the Siphon Gyroscope, is a triple-tiered platinum cradle holding a miniature black hole singularity that bends ambient light. Three ruby-red Sovereign's Marks orbit the core independently at offset angles, forming a spinning, multi-axis gyroscope wrapped in a swirling aura of pitch-black power and arcing silver light. It is the instrument through which the Vital Vector is extracted.

**The one unmade relic**: Vorifex is singular in every sense the other relics are not. Where the Gorget, Seal, and Vestments are remade or newly commissioned at each succession, Vorifex is never forged again — the same staff, unchanged, since the era Section II's doctrine holds unverifiable and unchallengeable. No Faber Reliquiarum in living memory has ever built one; none could. What exists, exists once.

**The singularity's origin**: Doctrine offers no mechanism for the Siphon Gyroscope's core, and this is by design rather than oversight. It is spoken of, when spoken of at all, as a gift of the founding era — a thing simply present at the start of the line, with no account of how it came to be. This absence is not treated as a gap to be filled but as confirmation of the doctrine already governing the Inanifex's own lineage: an origin nobody can verify is an origin nobody can challenge, and Vorifex is the physical proof of that principle as much as the throne itself is. Questioning its origin is treated as faintly heretical.

**The Bound Hunger**: The singularity was not found — it was *made*, forged in the same act that made the first Inanifex. Doctrine holds it as a Bound Hunger: a fragment of pure, directionless consumption pulled loose from the natural order and collared inside the Siphon Gyroscope, where the three orbiting Sovereign's Marks act less as ornament than as a leash, holding its appetite in constant, controlled rotation. It does not grow, does not feed itself — it only bends what passes near it, the way it bends torchlight, and that bending is precisely what makes a Vital Vector visible and extractable in the first place. Should the Marks ever stop their orbit — through the staff's destruction, a Striking gone wrong, or deliberate sabotage — the Hunger, unbound, would stop bending trajectories selectively and simply take the nearest one, indiscriminately, all at once, with no Aperture required and no consent asked. This is why Vorifex never leaves the Inanifex's hand during any Rendering, and why the Faber Reliquiarum's molds for the Gyroscope's cradle are the most closely guarded secret the Order of Smiths keeps.

**Binding to the winner of the Contest**: Vorifex does not answer to the Gorget, ceremony, or bloodline alone. It bonds, mechanically and absolutely, to whoever most recently completed a full Vector Contest and won the required two-thirds majority of the Nine (Section II). This is the true enforcement mechanism behind succession law: a pretender who seized the office by force, without the Contest, without the vote, could wear the Gorget, don the Vestments, stand at the Ivory Threshold — and Vorifex would not turn for him. The staff itself is the final, uncorruptible witness to legitimacy.

### The Fractae (Lesser Staffs)

Struck from the same pale ivory as Vorifex, but set with a cold silver shard in a two-tier cradle rather than a singularity. Carried by the Exactorii for field work; sever rather than extract whole.

**Two tiers of ownership**: Each of the Nine Seats possesses one dedicated Fracta, tied to the office itself rather than the individual — when a minister ascends or is Struck, his Fracta remains behind, passed to whoever next fills that Seat, carrying no record, darkening, or trace of past Cuts; it is simply reassigned, the same instrument doing the same work under a new numeral. Every other Fracta-bearer — the ordinary Exactorii performing field work — owns their own staff personally, granted at investiture into the Order and kept as his own for as long as he serves. When an Exactor dies or falls from the Order, his Fracta is retired or reforged, never simply handed to the next man in his place. Ownership splits along the same governing/follower divide as the rest of the hierarchy: the Nine hold office-bound relics, everyone beneath holds personal ones.

### The Fire Agate

The Fire Agate is not purely ornamental. It is the material that visibly channels and focuses sovereign and extracted power throughout the codex — flashing bronze-gold and orange fire along the Exhaurim Vestments' platinum seams, resonating during a Rendering, and serving as the vessel for "a captured spark of the Sovereign's authority" in the Ember Reliquary (Section XI). It is not a separate relic so much as the recurring material signature of power made visible, wherever it appears.

---

## XIII. Visual Direction

The visual style bridges two distinct generation pathways:

1. **Archaic Grandeur** — heavily formalized medieval illuminated manuscripts depicting the Sovereign enshrined within the Iron Decrees.
2. **Hyper-Real Imposing Realism** — a living dark messiah manifesting in full regalia.

Across both mediums, the color discipline remains unyielding: arterial crimson, dead-gloss obsidian, sterile platinum, flawless pale ivory, cold-emitting silver light, punctuated by the bronze-gold and orange fire of the agates. Warmth, benevolence, and pastoral softness are rejected throughout.

---

## XIV. The Iron Decrees (The Tome) — Reserved for Last

*Moved to the end of the codex per your instruction — to be fleshed out once the rest of the canon below it is locked, drawing on everything established above.*

**Material & Structure**: A massive ritual tome bound in cold-forged iron plates over crimson leather. Houses medieval-style illuminated manuscript depictions of the Sovereign. Inlaid with geometric channels that hum and pulse with a faint, cold silver light when activated.

**Established role so far**: Sole authority to inscribe or amend it belongs to the Custos Doctrinae (Seat II of the Inanifexacy). It is read from at every Silent Convocation. It describes the Reversion as the highest honor the Inanifexate can bestow, and records the honored dead as monuments rather than losses.

**Still open** (the actual laws, prophecies, and doctrines written inside — what it commands, promises, and forbids) — reserved for the next piece of work, as planned.

---

## Appendix: Locked Canon at a Glance

- **Empire/cult**: The Inanifexate · **Governing body**: The Inanifexacy (Nine Seats) · **Apex sovereign**: The Inanifex
- **Sigil**: The Sovereign's Mark (jagged lightning bolt) · **Siphoned essence**: The Vital Vector
- **Instruments**: Vorifex (whole, public, holy) / the Fractae (partial, private, "the Cut")
- **Relics**: The Inanifex Gorget, The Fracturing Seal, The Exhaurim Vestments, Vorifex, The Iron Decrees
- **Palette**: Deep Crimson, Polished Platinum, Obsidian Black, Pale Ivory, Cold Silver, Fire Agate flashes
- **Nine Offices**: Primus Exactor, Custos Doctrinae, Magister Vectorum, Praefectus Silenti, Aedilis Sanguinis, Faber Reliquiarum, Argentarius Inanifexis, Nuntius Exterior, Vox Inanifexis
- **Seven Orders**: Exactorii, Silenti, Scribae Vectorum, Legati, Reliquarii, Nutritores, Cultores Inanifexis
- **Seven Grades**: Feudatories, Benefacti, Vocati, Branded, Tolerated, Ledger-Born, Unentered
- **Mark renditions**: Burning (Inanifex) → Dull (the Nine) → Blood-Bronze (Feudatories) → Iron (Orders) → Ash (Vocati/Branded) → Cinder (Benefacti)
- **Modes of consent**: The Reversion (willing) · The Tithe-Rendering (coerced contract) · The Harvest/the Cut (deceived or field-taken)
- **Key rites**: The Silent Convocation, The Binding of the Shard, The Threshold Rite, The Striking, The Lapse
- **Litany**: *"Quod fuit, cessat."* — "What was, ceases."
- **Temple**: The Hall of the Rising Mark — jagged bolt-shaped spires, obsidian and silver, Nave of Rings (Grade determines ring distance from the altar)
- **Worship tiers**: The Daily Stilling (brief, four times daily) and the Ember Vigil (full seasonal service — Ordeal of Stillness → Procession → Recitation → the Raising)
- **New relic**: The Ember Reliquary — vessel holding a fire-agate fragment, carried in procession
- **Succession**: candidates must be **Feudatory bloodline** only; selected via the **Vector Contest**, confirmed by a **two-thirds majority** of the Nine; losers either resume rank or choose permanent banishment
- **Lineage**: held to be ancient, but deliberately **unverifiable** — history is authored by the Custos Doctrinae via the Iron Decrees, not independently recorded
- **Reach**: one **Prime Seat** (where the Inanifex resides, sole ground for Renderings) plus worldwide **Cadet Halls**, recognized via the Nuntius Exterior; distant authority enforced through **Voicings (Edicta Vocis)** issued by the Vox Inanifexis
- **Relic depth**: each Inanifex forges his own Gorget (lineage folded in as a sliver) and multiple Exhaurim Vestments (occasion-scaled); the Fracturing Seal's obsidian face is one unbroken shard across all successions; Vorifex is the sole relic never remade, bound mechanically to whoever last won the Vector Contest; its singularity is doctrine's **Bound Hunger**, unleashed indiscriminately if ever unbound; Fire Agate is the recurring material signature of power, not a standalone relic