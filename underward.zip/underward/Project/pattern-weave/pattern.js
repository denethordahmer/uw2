/* =========================================================================
   PATTERN WEAVER — pattern.js
   Ten pattern styles: Islamic geometry, Celtic knotwork, repeating motif,
   procedural rules, lattice, spiral rose, stained glass, medallion,
   terrazzo, hex weave. Seeded RNG, live preview, PNG/JPG export.
   Color system: 4 pattern colors + background(s), 15 color schemes,
   per-color opacity, HSL editing, gradient backgrounds, saved palettes.
   Pure client-side. No dependencies.
   ========================================================================= */

(function () {
  "use strict";

  /* =======================================================================
     DOM REFERENCES
     ======================================================================= */
  const canvas = document.getElementById("patternCanvas");
  let ctx = canvas.getContext("2d");

  const patternStyle  = document.getElementById("patternStyle");
  const seed          = document.getElementById("seed");
  const btnRandomizeSeed = document.getElementById("btnRandomizeSeed");
  const btnRandomizeAll  = document.getElementById("btnRandomizeAll");
  const btnRandomizeTop  = document.getElementById("btnRandomizeTop");

  // Color scheme
  const colorScheme    = document.getElementById("colorScheme");

  // Active color editor
  const colorTabs        = Array.from(document.querySelectorAll(".colorTab"));
  const activeColorLabel = document.getElementById("activeColorLabel");
  const activeColorInput = document.getElementById("activeColorInput");
  const activeColorSwatch = document.getElementById("activeColorSwatch");
  const hueSlider     = document.getElementById("hueSlider");
  const satSlider     = document.getElementById("satSlider");
  const lightSlider   = document.getElementById("lightSlider");
  const opacitySlider = document.getElementById("opacitySlider");
  const valHue        = document.getElementById("valHue");
  const valSat        = document.getElementById("valSat");
  const valLight      = document.getElementById("valLight");
  const valOpacity    = document.getElementById("valOpacity");

  // Background
  const bgStyle       = document.getElementById("bgStyle");
  const bgDir         = document.getElementById("bgDir");
  const bgDirRow      = document.getElementById("bgDirRow");

  // Saved custom palettes
  const palettePresetList = document.getElementById("palettePresetList");
  const btnSavePalette    = document.getElementById("btnSavePalette");
  const btnLoadPalette    = document.getElementById("btnLoadPalette");
  const btnDeletePalette  = document.getElementById("btnDeletePalette");

  const symmetry      = document.getElementById("symmetry");
  const scale         = document.getElementById("scale");
  const density       = document.getElementById("density");
  const lineWeight    = document.getElementById("lineWeight");
  const rotation      = document.getElementById("rotation");

  // Islamic
  const starPoints    = document.getElementById("starPoints");
  const ringCount     = document.getElementById("ringCount");
  const tessellation  = document.getElementById("tessellation");

  // Celtic
  const weaveStyle    = document.getElementById("weaveStyle");
  const loopCount     = document.getElementById("loopCount");
  const ribbonWidth   = document.getElementById("ribbonWidth");

  // Motif
  const motifType     = document.getElementById("motifType");
  const tileRotation  = document.getElementById("tileRotation");
  const tileOffset    = document.getElementById("tileOffset");

  // Procedural
  const ruleSet       = document.getElementById("ruleSet");
  const mutationRate  = document.getElementById("mutationRate");
  const growthSteps   = document.getElementById("growthSteps");

  // Lattice
  const latticeStyle  = document.getElementById("latticeStyle");
  const latticeWeave  = document.getElementById("latticeWeave");

  // Spiral Rose
  const spiralArms    = document.getElementById("spiralArms");
  const spiralType    = document.getElementById("spiralType");
  const spiralCurvature = document.getElementById("spiralCurvature");

  // Stained glass
  const glassCells    = document.getElementById("glassCells");
  const glassStyle    = document.getElementById("glassStyle");
  const glassOutline  = document.getElementById("glassOutline");

  // Medallion
  const medallionRings  = document.getElementById("medallionRings");
  const medallionPoints = document.getElementById("medallionPoints");
  const medallionFrame  = document.getElementById("medallionFrame");

  // Terrazzo
  const terrazzoDensity = document.getElementById("terrazzoDensity");
  const terrazzoSize    = document.getElementById("terrazzoSize");
  const terrazzoShape   = document.getElementById("terrazzoShape");

  // Hex weave
  const hexScale       = document.getElementById("hexScale");
  const hexWeave       = document.getElementById("hexWeave");

  // Export
  const exportScale   = document.getElementById("exportScale");
  const exportBg      = document.getElementById("exportBg");
  const exportName    = document.getElementById("exportName");
  const btnExportPng  = document.getElementById("btnExportPng");
  const btnExportJpg  = document.getElementById("btnExportJpg");
  const btnCopySeed   = document.getElementById("btnCopySeed");

  // Full-settings presets
  const presetList    = document.getElementById("presetList");
  const btnSavePreset = document.getElementById("btnSavePreset");
  const btnLoadPreset = document.getElementById("btnLoadPreset");
  const btnDeletePreset = document.getElementById("btnDeletePreset");

  // Style groups
  const styleIslamic  = document.getElementById("styleIslamic");
  const styleCeltic   = document.getElementById("styleCeltic");
  const styleMotif    = document.getElementById("styleMotif");
  const styleProcedural = document.getElementById("styleProcedural");
  const styleLattice    = document.getElementById("styleLattice");
  const styleSpiral     = document.getElementById("styleSpiral");
  const styleGlass      = document.getElementById("styleGlass");
  const styleMedallion  = document.getElementById("styleMedallion");
  const styleTerrazzo   = document.getElementById("styleTerrazzo");
  const styleHex        = document.getElementById("styleHex");

  // Value displays
  const valScale        = document.getElementById("valScale");
  const valDensity      = document.getElementById("valDensity");
  const valLineWeight   = document.getElementById("valLineWeight");
  const valMutationRate = document.getElementById("valMutationRate");
  const valSpiralCurvature = document.getElementById("valSpiralCurvature");
  const valGlassOutline    = document.getElementById("valGlassOutline");
  const valTerrazzoDensity = document.getElementById("valTerrazzoDensity");

  /* =======================================================================
     CANVAS SIZE
     ======================================================================= */
  const CANVAS_SIZE = 900;
  canvas.width = CANVAS_SIZE;
  canvas.height = CANVAS_SIZE;

  /* =======================================================================
     COLOR STATE
     ======================================================================= */
  const PATTERN_SLOTS = ["color1", "color2", "color3", "color4"];
  const ALL_SLOTS = ["color1", "color2", "color3", "color4", "bg", "bg2"];

  const colors = {
    color1: "#7c5cff",
    color2: "#38bdf8",
    color3: "#f472b6",
    color4: "#ffd257",
    bg:     "#07080d",
    bg2:    "#1c2130"
  };

  const opacities = {
    color1: 100,
    color2: 100,
    color3: 100,
    color4: 100,
    bg:     100,
    bg2:    100
  };

  let activeSlot = "color1";

  /* =======================================================================
     COLOR HELPERS
     ======================================================================= */
  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  function hexToRgb(hex) {
    let h = String(hex || "").replace("#", "");
    if (h.length === 3) {
      h = h.split("").map(c => c + c).join("");
    }
    const num = parseInt(h, 16);
    if (isNaN(num)) return { r: 124, g: 92, b: 255 };
    return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
  }

  function rgbToHex(r, g, b) {
    const to = v => clamp(Math.round(v), 0, 255).toString(16).padStart(2, "0");
    return "#" + to(r) + to(g) + to(b);
  }

  function rgbToHsl(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0, s = 0;
    const l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      if (max === r) h = (g - b) / d + (g < b ? 6 : 0);
      else if (max === g) h = (b - r) / d + 2;
      else h = (r - g) / d + 4;
      h *= 60;
    }
    return { h: clamp(h, 0, 360), s: clamp(s * 100, 0, 100), l: clamp(l * 100, 0, 100) };
  }

  function hslToRgb(h, s, l) {
    h = ((h % 360) + 360) % 360;
    s /= 100; l /= 100;

    if (s === 0) {
      const v = l * 255;
      return { r: v, g: v, b: v };
    }

    const hue = h / 360;
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;

    const hue2rgb = t => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1 / 6) return p + (q - p) * 6 * t;
      if (t < 1 / 2) return q;
      if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6;
      return p;
    };

    return {
      r: hue2rgb(hue + 1 / 3) * 255,
      g: hue2rgb(hue) * 255,
      b: hue2rgb(hue - 1 / 3) * 255
    };
  }

  function hexToHsl(hex) {
    const c = hexToRgb(hex);
    return rgbToHsl(c.r, c.g, c.b);
  }

  function hslToHex(h, s, l) {
    const c = hslToRgb(h, s, l);
    return rgbToHex(c.r, c.g, c.b);
  }

  function hexToRgba(hex, alpha) {
    const c = hexToRgb(hex);
    return `rgba(${c.r},${c.g},${c.b},${clamp(alpha, 0, 1)})`;
  }

  function rgbaOf(slot, alpha) {
    const hex = colors[slot] || "#ffffff";
    const op = (opacities[slot] == null ? 100 : opacities[slot]) / 100;
    return hexToRgba(hex, alpha * op);
  }

  function pickColor(minA, maxA) {
    const slot = PATTERN_SLOTS[Math.floor(rng() * PATTERN_SLOTS.length)];
    const alpha = minA + rng() * (maxA - minA);
    return rgbaOf(slot, alpha);
  }

  function pickColorInfo(minA, maxA) {
    const slot = PATTERN_SLOTS[Math.floor(rng() * PATTERN_SLOTS.length)];
    const alpha = minA + rng() * (maxA - minA);
    return {
      slot: slot,
      color: rgbaOf(slot, alpha),
      fill: rgbaOf(slot, alpha * 0.22)
    };
  }

  /* =======================================================================
     COLOR SCHEMES — 15 total
     ======================================================================= */
  const ALL_SCHEMES = [
    "complementary", "splitcomp", "analogous", "triadic", "tetradic",
    "doublesplit", "monochrome", "duotone",
    "jewel", "pastel", "earth", "neon", "noir", "parchment", "ocean"
  ];

  const SCHEME_PALETTES = {
    jewel:     ["#059669", "#2563eb", "#8b5cf6", "#eab308", "#05060a", "#111827"],
    pastel:    ["#a5b4fc", "#f0abfc", "#99f6e4", "#fde68a", "#0b1020", "#1e1b3a"],
    earth:     ["#c2703d", "#b08d3d", "#d9c7a0", "#7a7a52", "#1a1512", "#2a211c"],
    neon:      ["#00e5ff", "#ff00e5", "#aaff00", "#b026ff", "#000000", "#0a0a0a"],
    noir:      ["#ff3b3b", "#e5e7eb", "#9ca3af", "#4b5563", "#0a0a0a", "#1a1a1a"],
    parchment: ["#5b3a1e", "#8b5e34", "#3d2b1f", "#a4713a", "#f2e6c9", "#e0cfae"],
    ocean:     ["#0ea5e9", "#14b8a6", "#e0f2fe", "#7dd3c8", "#020c1b", "#0a2a44"]
  };

  function randomBaseColor() {
    const h = Math.floor(Math.random() * 360);
    const s = 60 + Math.floor(Math.random() * 30);
    const l = 55 + Math.floor(Math.random() * 20);
    return hslToHex(h, s, l);
  }

  function harmonyColors(baseHex, rule) {
    const base = hexToHsl(baseHex);
    const h = base.h, s = base.s, l = base.l;
    const hue = deg => (((h + deg) % 360) + 360) % 360;

    let arr = [];
    if (rule === "complementary") {
      arr = [
        { h: h,        s: s,                   l: l },
        { h: hue(180), s: s,                   l: l },
        { h: h,        s: clamp(s - 15, 0, 100), l: clamp(l + 15, 0, 100) },
        { h: hue(180), s: clamp(s - 15, 0, 100), l: clamp(l + 15, 0, 100) }
      ];
    } else if (rule === "analogous") {
      arr = [
        { h: hue(-40), s: s, l: l },
        { h: hue(-20), s: s, l: l },
        { h: hue(20),  s: s, l: l },
        { h: hue(40),  s: s, l: l }
      ];
    } else if (rule === "triadic") {
      arr = [
        { h: h,        s: s,                   l: l },
        { h: hue(120), s: s,                   l: l },
        { h: hue(240), s: s,                   l: l },
        { h: h,        s: clamp(s - 10, 0, 100), l: clamp(l + 18, 0, 100) }
      ];
    } else if (rule === "split") {
      arr = [
        { h: h,        s: s,                   l: l },
        { h: hue(150), s: s,                   l: l },
        { h: hue(210), s: s,                   l: l },
        { h: hue(-15), s: clamp(s - 10, 0, 100), l: clamp(l + 12, 0, 100) }
      ];
    }

    return arr.map(c => hslToHex(c.h, c.s, c.l));
  }

  function schemeOutput(scheme) {
    if (SCHEME_PALETTES[scheme]) {
      return SCHEME_PALETTES[scheme].slice();
    }

    const base = randomBaseColor();
    const hslB = hexToHsl(base);
    let four;

    if (scheme === "tetradic") {
      four = [0, 90, 180, 270].map(d => hslToHex(((hslB.h + d) % 360 + 360) % 360, hslB.s, hslB.l));
    } else if (scheme === "doublesplit") {
      four = [0, 150, 210, 180].map(d => hslToHex(((hslB.h + d) % 360 + 360) % 360, hslB.s, hslB.l));
    } else if (scheme === "monochrome") {
      four = [
        hslToHex(hslB.h, 60, 90),
        hslToHex(hslB.h, 55, 70),
        hslToHex(hslB.h, 45, 45),
        hslToHex(hslB.h, 35, 22)
      ];
    } else if (scheme === "duotone") {
      const h2 = ((hslB.h + 180) % 360 + 360) % 360;
      four = [
        hslToHex(hslB.h, 70, 60),
        hslToHex(h2, 70, 60),
        hslToHex(hslB.h, 70, 78),
        hslToHex(h2, 70, 78)
      ];
    } else {
      const rule = {
        complementary: "complementary",
        splitcomp:     "split",
        analogous:     "analogous",
        triadic:       "triadic"
      }[scheme];
      four = harmonyColors(base, rule);
    }

    return [four[0], four[1], four[2], four[3], "#07080d", "#1c2130"];
  }

  function applyColorScheme(scheme) {
    const out = schemeOutput(scheme);
    PATTERN_SLOTS.forEach((slot, i) => { colors[slot] = out[i]; });
    colors.bg  = out[4];
    colors.bg2 = out[5];
    ALL_SLOTS.forEach(slot => { opacities[slot] = 100; });
    updateColorEditor();
  }

  /* =======================================================================
     COLOR UI
     ======================================================================= */
  const SLOT_LABELS = {
    color1: "Color 1",
    color2: "Color 2",
    color3: "Color 3",
    color4: "Color 4",
    bg:     "Background",
    bg2:    "Background 2"
  };

  function setActiveSlot(slot) {
    if (!colors[slot]) return;
    activeSlot = slot;
    updateColorEditor();
  }

  function updateColorEditor() {
    const isGradient = bgStyle.value !== "solid";
    const bg2Btn = document.getElementById("tab_bg2");
    if (bg2Btn) bg2Btn.classList.toggle("hidden", !isGradient);
    if (!isGradient && activeSlot === "bg2") activeSlot = "bg";

    colorTabs.forEach(btn => {
      const slot = btn.dataset.slot;
      btn.style.background = colors[slot] || "#ffffff";
      btn.classList.toggle("active", slot === activeSlot);
    });

    activeColorLabel.textContent = SLOT_LABELS[activeSlot] || activeSlot;

    const hex = colors[activeSlot];
    const hsl = hexToHsl(hex);
    activeColorInput.value = hex;
    if (activeColorSwatch) activeColorSwatch.style.background = hex;

    hueSlider.value = Math.round(hsl.h);
    satSlider.value = Math.round(hsl.s);
    lightSlider.value = Math.round(hsl.l);
    valHue.textContent = Math.round(hsl.h);
    valSat.textContent = Math.round(hsl.s);
    valLight.textContent = Math.round(hsl.l);

    opacitySlider.value = opacities[activeSlot] == null ? 100 : opacities[activeSlot];
    valOpacity.textContent = opacitySlider.value;
  }

  function updateBgControls() {
    const dirRow = document.getElementById("bgDirRow");
    if (dirRow) dirRow.classList.toggle("hidden", bgStyle.value !== "linear");
    updateColorEditor();
  }

  /* =======================================================================
     SEEDED RNG (mulberry32)
     ======================================================================= */
  function hashSeed(str) {
    let h = 2166136261 >>> 0;
    const s = String(str || "");
    for (let i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619);
    }
    return h >>> 0;
  }

  function mulberry32(a) {
    return function () {
      a |= 0;
      a = a + 0x6D2B79F5 | 0;
      let t = a;
      t = Math.imul(t ^ t >>> 15, t | 1);
      t ^= t + Math.imul(t ^ t >>> 7, t | 61);
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }

  let rng = mulberry32(hashSeed(seed.value));

  function reseed() {
    rng = mulberry32(hashSeed(seed.value || "default"));
  }

  /* =======================================================================
     DRAW HELPERS
     ======================================================================= */
  function prepareContext(c) {
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.globalAlpha = 1;
    c.globalCompositeOperation = "source-over";
    c.lineCap = "butt";
    c.lineJoin = "miter";
    c.clearRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);
  }

  function resetDrawingState(c) {
    c.lineCap = "butt";
    c.lineJoin = "miter";
    c.globalAlpha = 1;
    c.globalCompositeOperation = "source-over";
  }

  function paintBackground(c) {
    const style = bgStyle.value;

    if (style === "solid") {
      c.fillStyle = rgbaOf("bg", 1);
      c.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);
      return;
    }

    let g;
    if (style === "radial") {
      g = c.createRadialGradient(
        CANVAS_SIZE / 2, CANVAS_SIZE / 2, 0,
        CANVAS_SIZE / 2, CANVAS_SIZE / 2, CANVAS_SIZE * 0.62
      );
    } else {
      const dir = bgDir.value;
      const coords = {
        "to-bottom":       [0, 0, 0, CANVAS_SIZE],
        "to-top":          [0, CANVAS_SIZE, 0, 0],
        "to-right":        [0, 0, CANVAS_SIZE, 0],
        "to-left":         [CANVAS_SIZE, 0, 0, 0],
        "to-bottom-right": [0, 0, CANVAS_SIZE, CANVAS_SIZE],
        "to-bottom-left":  [CANVAS_SIZE, 0, 0, CANVAS_SIZE],
        "to-top-right":    [0, CANVAS_SIZE, CANVAS_SIZE, 0],
        "to-top-left":     [CANVAS_SIZE, CANVAS_SIZE, 0, 0]
      };
      const d = coords[dir] || coords["to-bottom"];
      g = c.createLinearGradient(d[0], d[1], d[2], d[3]);
    }

    g.addColorStop(0, rgbaOf("bg", 1));
    g.addColorStop(1, rgbaOf("bg2", 1));
    c.fillStyle = g;
    c.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);
  }

  /* =======================================================================
     STYLE 1 — ISLAMIC GEOMETRY
     ======================================================================= */
  function drawIslamic() {
    const cx = CANVAS_SIZE / 2;
    const cy = CANVAS_SIZE / 2;
    const points = parseInt(starPoints.value, 10);
    const rings = parseInt(ringCount.value, 10);
    const sym = parseInt(symmetry.value, 10);
    const sc = parseFloat(scale.value);
    const dens = parseInt(density.value, 10) / 100;
    const lw = parseInt(lineWeight.value, 10);
    const rot = parseInt(rotation.value, 10) * Math.PI / 180;
    const tess = tessellation.value;

    const baseRadius = (CANVAS_SIZE / 2) * 0.42 * sc;

    for (let r = 1; r <= rings; r++) {
      const radius = baseRadius * (r / rings);
      const ringPoints = sym * r;

      for (let i = 0; i < ringPoints; i++) {
        const angle = (i / ringPoints) * Math.PI * 2 + rot;
        const sx = cx + Math.cos(angle) * radius;
        const sy = cy + Math.sin(angle) * radius;
        const starR = radius * 0.35 * (1 - dens * 0.4) * (1 + rng() * 0.15);
        drawStar(sx, sy, points, starR, points * 1.5, lw, pickColor(0.6, 0.9));
      }
    }

    drawStar(cx, cy, points * 2, baseRadius * 0.45, points * 3, lw * 1.5, rgbaOf("color1", 1));

    if (tess !== "star") {
      ctx.strokeStyle = rgbaOf("color2", 0.35);
      ctx.lineWidth = Math.max(1, lw * 0.5);
      for (let r = 0; r < rings; r++) {
        const radius = baseRadius * ((r + 1) / rings);
        const ringPoints = sym * (r + 1);
        ctx.beginPath();
        for (let i = 0; i <= ringPoints; i++) {
          const angle = (i / ringPoints) * Math.PI * 2 + rot;
          const x = cx + Math.cos(angle) * radius;
          const y = cy + Math.sin(angle) * radius;
          if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
    }
  }

  function drawStar(cx, cy, points, outerR, innerR, lw, color) {
    ctx.beginPath();
    for (let i = 0; i < points * 2; i++) {
      const angle = (i / (points * 2)) * Math.PI * 2 - Math.PI / 2;
      const r = i % 2 === 0 ? outerR : innerR;
      const x = cx + Math.cos(angle) * r;
      const y = cy + Math.sin(angle) * r;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.strokeStyle = color;
    ctx.lineWidth = lw;
    ctx.stroke();
  }

  /* =======================================================================
     STYLE 2 — CELTIC KNOTWORK
     ======================================================================= */
  function drawCeltic() {
    const cx = CANVAS_SIZE / 2;
    const cy = CANVAS_SIZE / 2;
    const loops = parseInt(loopCount.value, 10);
    const sym = parseInt(symmetry.value, 10);
    const sc = parseFloat(scale.value);
    const dens = parseInt(density.value, 10) / 100;
    const lw = parseInt(lineWeight.value, 10);
    const rot = parseInt(rotation.value, 10) * Math.PI / 180;
    const weave = weaveStyle.value;
    const widthChoice = ribbonWidth.value;
    const ribbonW = widthChoice === "thin" ? lw : widthChoice === "medium" ? lw * 1.8 : lw * 3;

    const baseRadius = (CANVAS_SIZE / 2) * 0.42 * sc;

    for (let i = 0; i < sym; i++) {
      const angle = (i / sym) * Math.PI * 2 + rot;
      const offset = baseRadius * 0.55 * (1 - dens * 0.3);
      const ox = cx + Math.cos(angle) * offset;
      const oy = cy + Math.sin(angle) * offset;

      for (let l = 0; l < loops; l++) {
        const r = baseRadius * (0.35 + l * 0.2) * (1 + rng() * 0.1);
        drawKnotRing(ox, oy, r, ribbonW, weave, i, l);
      }
    }

    const centerR = baseRadius * 0.25;
    drawKnotRing(cx, cy, centerR, ribbonW * 1.2, weave, 999, 0);
  }

  function drawKnotRing(cx, cy, radius, width, weaveStyle, index, loopIdx) {
    const colorA = rgbaOf("color1", 0.85);
    const colorB = rgbaOf("color2", 0.85);
    const accent = rgbaOf("color3", 0.9);

    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.lineWidth = width;
    ctx.strokeStyle = index % 2 === 0 ? colorA : colorB;
    ctx.stroke();

    if (weaveStyle !== "balanced" || loopIdx % 2 === 0) {
      const segments = 8;
      for (let s = 0; s < segments; s++) {
        const startAngle = (s / segments) * Math.PI * 2 + rng() * 0.3;
        const endAngle = startAngle + (Math.PI * 2 / segments) * 0.4;
        ctx.beginPath();
        ctx.arc(cx, cy, radius, startAngle, endAngle);
        ctx.lineWidth = width * 1.15;
        ctx.strokeStyle = accent;
        ctx.stroke();
      }
    }
  }

  /* =======================================================================
     STYLE 3 — REPEATING MOTIF
     ======================================================================= */
  function drawMotif() {
    const sc = parseFloat(scale.value);
    const dens = parseInt(density.value, 10) / 100;
    const lw = parseInt(lineWeight.value, 10);
    const rot = parseInt(rotation.value, 10) * Math.PI / 180;
    const mtype = motifType.value;
    const trot = tileRotation.value;
    const toff = tileOffset.value;

    const gridSize = Math.max(3, Math.round(6 + sc * 6));
    const cell = CANVAS_SIZE / gridSize;

    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        let cx = x * cell + cell / 2;
        let cy = y * cell + cell / 2;

        if (toff === "brick" && y % 2 === 1) cx += cell / 2;
        if (toff === "diagonal") {
          cx += (y % 2) * cell / 2;
          cy += (x % 2) * cell / 2;
        }

        let tileRot = rot;
        if (trot === "90") tileRot += (x + y) * Math.PI / 2;
        else if (trot === "180") tileRot += (x + y) * Math.PI;
        else if (trot === "mirror") {
          if ((x + y) % 2 === 1) tileRot += Math.PI;
        }

        const size = cell * 0.35 * (0.7 + rng() * 0.6) * (1 - dens * 0.3);
        const info = pickColorInfo(0.55, 0.95);

        drawMotifShape(cx, cy, size, tileRot, mtype, lw, info.color, info.fill);
      }
    }
  }

  function drawMotifShape(cx, cy, size, rot, type, lw, color, fillColor) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(rot);
    ctx.strokeStyle = color;
    ctx.fillStyle = fillColor;
    ctx.lineWidth = lw;

    if (type === "dot") {
      ctx.beginPath();
      ctx.arc(0, 0, size * 0.5, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fill();
    } else if (type === "diamond") {
      ctx.beginPath();
      ctx.moveTo(0, -size);
      ctx.lineTo(size, 0);
      ctx.lineTo(0, size);
      ctx.lineTo(-size, 0);
      ctx.closePath();
      ctx.stroke();
      ctx.fill();
    } else if (type === "petal") {
      ctx.beginPath();
      for (let i = 0; i < 4; i++) {
        const a = (i / 4) * Math.PI * 2;
        ctx.moveTo(0, 0);
        ctx.quadraticCurveTo(
          Math.cos(a) * size, Math.sin(a) * size,
          Math.cos(a + Math.PI / 2) * size, Math.sin(a + Math.PI / 2) * size
        );
      }
      ctx.stroke();
    } else if (type === "arrow") {
      ctx.beginPath();
      ctx.moveTo(0, -size);
      ctx.lineTo(size * 0.6, size * 0.6);
      ctx.lineTo(0, size * 0.3);
      ctx.lineTo(-size * 0.6, size * 0.6);
      ctx.closePath();
      ctx.stroke();
      ctx.fill();
    } else if (type === "eye") {
      ctx.beginPath();
      ctx.ellipse(0, 0, size, size * 0.5, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.beginPath();
      ctx.arc(0, 0, size * 0.25, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  /* =======================================================================
     STYLE 4 — PROCEDURAL RULES
     ======================================================================= */
  function drawProcedural() {
    const rule = ruleSet.value;
    const mut = parseInt(mutationRate.value, 10) / 100;
    const steps = parseInt(growthSteps.value, 10);
    const lw = parseInt(lineWeight.value, 10);
    const sc = parseFloat(scale.value);
    const dens = parseInt(density.value, 10) / 100;

    if (rule === "truchet") drawTruchet(mut, lw, sc, dens);
    else if (rule === "cellular") drawCellular(mut, lw, sc, dens);
    else if (rule === "flow") drawFlow(mut, lw, sc, dens);
    else if (rule === "branch") drawBranching(mut, lw, sc, dens, steps);
  }

  function drawTruchet(mut, lw, sc, dens) {
    const grid = Math.max(4, Math.round(6 + sc * 6));
    const cell = CANVAS_SIZE / grid;
    for (let y = 0; y < grid; y++) {
      for (let x = 0; x < grid; x++) {
        const ox = x * cell;
        const oy = y * cell;
        const flip = rng() < 0.5;
        const color = pickColor(0.4, 0.9);
        ctx.strokeStyle = color;
        ctx.lineWidth = lw * (0.6 + dens * 0.8);

        ctx.beginPath();
        if (flip) {
          ctx.arc(ox, oy, cell, 0, Math.PI / 2);
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(ox + cell, oy + cell, cell, Math.PI, Math.PI * 1.5);
          ctx.stroke();
        } else {
          ctx.arc(ox + cell, oy, cell, Math.PI / 2, Math.PI);
          ctx.stroke();
          ctx.beginPath();
          ctx.arc(ox, oy + cell, cell, 0, Math.PI / 2);
          ctx.stroke();
        }
      }
    }
  }

  function drawCellular(mut, lw, sc, dens) {
    const grid = Math.max(8, Math.round(10 + sc * 12));
    const cell = CANVAS_SIZE / grid;
    const alive = new Uint8Array(grid * grid);
    for (let i = 0; i < alive.length; i++) alive[i] = rng() < (0.4 + dens * 0.3) ? 1 : 0;

    for (let step = 0; step < 3 + Math.round(dens * 4); step++) {
      const next = new Uint8Array(alive.length);
      for (let y = 0; y < grid; y++) {
        for (let x = 0; x < grid; x++) {
          let n = 0;
          for (let dy = -1; dy <= 1; dy++) {
            for (let dx = -1; dx <= 1; dx++) {
              if (dx === 0 && dy === 0) continue;
              const nx = (x + dx + grid) % grid;
              const ny = (y + dy + grid) % grid;
              n += alive[ny * grid + nx];
            }
          }
          next[y * grid + x] = (alive[y * grid + x] ? (n === 2 || n === 3) : n === 3) ? 1 : 0;
          if (rng() < mut * 0.15) next[y * grid + x] ^= 1;
        }
      }
      for (let i = 0; i < alive.length; i++) alive[i] = next[i];
    }

    for (let y = 0; y < grid; y++) {
      for (let x = 0; x < grid; x++) {
        if (alive[y * grid + x]) {
          ctx.fillStyle = pickColor(0.5, 0.95);
          ctx.fillRect(x * cell, y * cell, cell, cell);
        }
      }
    }
  }

  function drawFlow(mut, lw, sc, dens) {
    const count = Math.round(40 + sc * 80);
    const steps = Math.round(30 + dens * 60);
    ctx.lineWidth = lw * 0.4;

    for (let i = 0; i < count; i++) {
      let x = rng() * CANVAS_SIZE;
      let y = rng() * CANVAS_SIZE;
      const seedA = rng() * 6;
      const seedB = rng() * 6;
      const color = pickColor(0.3, 0.8);
      ctx.strokeStyle = color;
      ctx.beginPath();
      ctx.moveTo(x, y);

      for (let s = 0; s < steps; s++) {
        const angle = Math.sin(x * 0.004 + seedA) + Math.cos(y * 0.004 + seedB) + (rng() - 0.5) * mut;
        x += Math.cos(angle) * 3;
        y += Math.sin(angle) * 3;
        if (x < 0 || x > CANVAS_SIZE || y < 0 || y > CANVAS_SIZE) break;
        ctx.lineTo(x, y);
      }
      ctx.stroke();
    }
  }

  function drawBranching(mut, lw, sc, dens, steps) {
    ctx.lineCap = "round";
    const safeSteps = Math.min(parseInt(steps, 10) || 5, 8);
    const treeCount = Math.max(3, Math.round(4 + sc * 3));

    for (let t = 0; t < treeCount; t++) {
      const startX = CANVAS_SIZE * (0.2 + (t + 0.5) / treeCount * 0.6);
      const startY = CANVAS_SIZE * 0.9;
      const angle = -Math.PI / 2 + (rng() - 0.5) * 0.3;
      branch(startX, startY, angle, CANVAS_SIZE * 0.22 * sc, safeSteps, lw, mut, dens);
    }
  }

  function branch(x, y, angle, length, depth, lw, mut, dens) {
    if (depth <= 0 || length < 3) return;
    const ex = x + Math.cos(angle) * length;
    const ey = y + Math.sin(angle) * length;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(ex, ey);
    ctx.strokeStyle = pickColor(0.5, 0.95);
    ctx.lineWidth = Math.max(1, lw * (depth / 6));
    ctx.stroke();

    const children = 2 + (rng() < 0.4 ? 1 : 0);
    for (let i = 0; i < children; i++) {
      const spread = (i - (children - 1) / 2) * (0.5 + rng() * 0.4) + (rng() - 0.5) * mut;
      branch(ex, ey, angle + spread, length * (0.65 + rng() * 0.2), depth - 1, lw, mut, dens);
    }
  }

  /* =======================================================================
     STYLE 5 — LATTICE
     Interlocking diagonal lattice of diamonds/squares/hexes with weave modes.
     ======================================================================= */
  function drawLattice() {
    const sc = parseFloat(scale.value);
    const lw = parseInt(lineWeight.value, 10);
    const dens = parseInt(density.value, 10) / 100;
    const rot = parseInt(rotation.value, 10) * Math.PI / 180;
    const style = latticeStyle.value;
    const weave = latticeWeave.value;

    const cell = Math.max(60, 120 * sc * (1.2 - dens * 0.5));
    const R = cell / 2;

    for (let row = -2; row <= CANVAS_SIZE / cell + 2; row++) {
      for (let col = -2; col <= CANVAS_SIZE / cell + 2; col++) {
        let x = col * cell + (row % 2 === 0 ? 0 : R);
        let y = row * cell * 0.75;

        // apply rotation around center
        const dx = x - CANVAS_SIZE / 2;
        const dy = y - CANVAS_SIZE / 2;
        x = CANVAS_SIZE / 2 + dx * Math.cos(rot) - dy * Math.sin(rot);
        y = CANVAS_SIZE / 2 + dx * Math.sin(rot) + dy * Math.cos(rot);

        if (x < -cell * 2 || x > CANVAS_SIZE + cell * 2) continue;
        if (y < -cell * 2 || y > CANVAS_SIZE + cell * 2) continue;

        const colA = rgbaOf("color1", 0.75);
        const colB = rgbaOf(weave === "gap" ? "color2" : "color2", 0.75);
        ctx.strokeStyle = (row + col) % 2 === 0 ? colA : colB;

        if (weave === "gap") {
          ctx.lineWidth = Math.max(1, lw * 0.6);
          const r = R * 0.72;
          ctx.beginPath();
          ctx.arc(x, y, r, 0, Math.PI * 2);
          ctx.stroke();
        } else {
          ctx.lineWidth = lw * (weave === "flat" ? 1.2 : 1.0);
          drawLatticeShape(x, y, R, style);
        }

        // Weave over-under: draw small accent segment across overlaps
        if (weave === "over" && (row + col) % 2 === 0) {
          ctx.strokeStyle = rgbaOf("color3", 0.9);
          ctx.lineWidth = Math.max(1, lw * 0.9);
          ctx.beginPath();
          ctx.moveTo(x - R * 0.8, y);
          ctx.lineTo(x + R * 0.8, y);
          ctx.stroke();
        }
      }
    }
  }

  function drawLatticeShape(x, y, R, style) {
    if (style === "diamond") {
      ctx.beginPath();
      ctx.moveTo(x, y - R);
      ctx.lineTo(x + R * 0.8, y);
      ctx.lineTo(x, y + R);
      ctx.lineTo(x - R * 0.8, y);
      ctx.closePath();
      ctx.stroke();
    } else if (style === "square") {
      ctx.strokeRect(x - R * 0.7, y - R * 0.7, R * 1.4, R * 1.4);
    } else {
      // hexagonal
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2 + Math.PI / 6;
        const px = x + Math.cos(a) * R * 0.8;
        const py = y + Math.sin(a) * R * 0.8;
        if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.stroke();
    }
  }

  /* =======================================================================
     STYLE 6 — SPIRAL ROSE
     Concentric logarithmic spirals radiating from center.
     ======================================================================= */
  function drawSpiral() {
    const cx = CANVAS_SIZE / 2;
    const cy = CANVAS_SIZE / 2;
    const arms = parseInt(spiralArms.value, 10);
    const sc = parseFloat(scale.value);
    const lw = parseInt(lineWeight.value, 10);
    const rot = parseInt(rotation.value, 10) * Math.PI / 180;
    const type = spiralType.value;
    const curv = parseInt(spiralCurvature.value, 10) / 100;

    ctx.lineCap = "round";
    const maxR = CANVAS_SIZE * 0.48 * sc;
    const turns = 3 + curv * 5;
    const growth = maxR / (turns * Math.PI * 2);

    for (let a = 0; a < arms; a++) {
      const armAngle = (a / arms) * Math.PI * 2 + rot;
      const color = rgbaOf("color" + ((a % 4) + 1), 0.85);

      ctx.strokeStyle = color;
      ctx.lineWidth = Math.max(1, lw * (0.5 + curv * 0.5));

      if (type === "rose") {
        // rose: petals as inward-curving arcs
        ctx.beginPath();
        for (let t = 0; t <= turns * Math.PI * 2; t += 0.1) {
          const r = t * growth;
          const x = cx + Math.cos(t + armAngle) * r;
          const y = cy + Math.sin(t + armAngle) * r;
          if (t === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.stroke();
      } else if (type === "vortex") {
        // vortex: tight logarithmic spiral
        ctx.beginPath();
        const b = 0.28 + curv * 0.5;
        for (let t = 0; t <= turns * Math.PI * 2; t += 0.06) {
          const r = Math.exp(t * b * 0.12) * 4;
          const x = cx + Math.cos(t + armAngle) * r;
          const y = cy + Math.sin(t + armAngle) * r;
          if (r > maxR) break;
          if (t === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.stroke();
      } else {
        // fern whorl: alternating short arcs
        for (let i = 0; i < 16 + curv * 24; i++) {
          const r = i * (maxR / (16 + curv * 24));
          const a0 = armAngle + i * 0.5;
          const a1 = armAngle + i * 0.5 + 0.6;
          ctx.beginPath();
          ctx.arc(cx, cy, r, a0, a1);
          ctx.stroke();
        }
      }
    }
  }

  /* =======================================================================
     STYLE 7 — STAINED GLASS
     Irregular polygon cells (Voronoi-like) with bold outlines.
     ======================================================================= */
  function drawGlass() {
    const cellMode = glassCells.value;
    const sc = parseFloat(scale.value);
    const lw = parseInt(glassOutline.value, 10);
    const rot = parseInt(rotation.value, 10) * Math.PI / 180;
    const style = glassStyle.value;

    const cellCount = cellMode === "coarse" ? 24 : cellMode === "medium" ? 60 : 130;
    const cellCountAdj = Math.round(cellCount * (0.6 + sc * 0.6));

    const points = [];
    for (let i = 0; i < cellCountAdj; i++) {
      let x, y;
      if (style === "circular") {
        const ang = rng() * Math.PI * 2;
        const rr = Math.sqrt(rng()) * CANVAS_SIZE * 0.5;
        x = CANVAS_SIZE / 2 + Math.cos(ang) * rr;
        y = CANVAS_SIZE / 2 + Math.sin(ang) * rr;
      } else {
        x = rng() * CANVAS_SIZE;
        y = rng() * CANVAS_SIZE;
      }
      // apply rotation
      const dx = x - CANVAS_SIZE / 2;
      const dy = y - CANVAS_SIZE / 2;
      x = CANVAS_SIZE / 2 + dx * Math.cos(rot) - dy * Math.sin(rot);
      y = CANVAS_SIZE / 2 + dx * Math.sin(rot) + dy * Math.cos(rot);
      points.push({ x, y });
    }

    // For each point, draw its region as a rough polygon (nearest-neighbor fill)
    const grid = 30;
    const cellSize = CANVAS_SIZE / grid;
    for (let gy = 0; gy < grid; gy++) {
      for (let gx = 0; gx < grid; gx++) {
        const px = gx * cellSize + cellSize / 2;
        const py = gy * cellSize + cellSize / 2;
        let best = -1, bestD = Infinity;
        for (let i = 0; i < points.length; i++) {
          const dx = points[i].x - px;
          const dy = points[i].y - py;
          const d = dx * dx + dy * dy;
          if (d < bestD) { bestD = d; best = i; }
        }
        ctx.fillStyle = rgbaOf("color" + ((best % 4) + 1), 0.4);
        ctx.fillRect(gx * cellSize, gy * cellSize, cellSize, cellSize);
      }
    }

    // Bold outlines: draw connecting lines between neighboring points
    ctx.strokeStyle = rgbaOf("bg", 1);
    ctx.lineWidth = lw;
    for (let i = 0; i < points.length; i++) {
      for (let j = i + 1; j < points.length; j++) {
        const dx = points[i].x - points[j].x;
        const dy = points[i].y - points[j].y;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < CANVAS_SIZE * 0.22 && rng() < 0.3) {
          ctx.beginPath();
          ctx.moveTo(points[i].x, points[i].y);
          ctx.lineTo(points[j].x, points[j].y);
          ctx.stroke();
        }
      }
    }
  }

  /* =======================================================================
     STYLE 8 — MEDALLION
     One large nested ring-and-star emblem with a border frame.
     ======================================================================= */
  function drawMedallion() {
    const cx = CANVAS_SIZE / 2;
    const cy = CANVAS_SIZE / 2;
    const rings = parseInt(medallionRings.value, 10);
    const points = parseInt(medallionPoints.value, 10);
    const sc = parseFloat(scale.value);
    const lw = parseInt(lineWeight.value, 10);
    const rot = parseInt(rotation.value, 10) * Math.PI / 180;
    const frame = medallionFrame.value;

    const R = CANVAS_SIZE * 0.38 * sc;

    // Star in center
    drawStar(cx, cy, points, R * 0.6, R * 0.28, lw * 1.4, rgbaOf("color1", 1));

    // Concentric rings
    for (let r = 1; r <= rings; r++) {
      const rr = R * (0.55 + r * 0.14);
      ctx.beginPath();
      ctx.arc(cx, cy, rr, 0, Math.PI * 2);
      ctx.strokeStyle = rgbaOf("color" + ((r % 4) + 1), 0.9);
      ctx.lineWidth = lw * (r === rings ? 1.5 : 1.0);
      ctx.stroke();

      // ring ornaments
      const ornamentCount = points * r;
      for (let o = 0; o < ornamentCount; o++) {
        const ang = (o / ornamentCount) * Math.PI * 2 + rot;
        const ox = cx + Math.cos(ang) * rr;
        const oy = cy + Math.sin(ang) * rr;
        ctx.beginPath();
        ctx.arc(ox, oy, lw * 0.7, 0, Math.PI * 2);
        ctx.fillStyle = rgbaOf("color4", 0.9);
        ctx.fill();
      }
    }

    // Frame border
    const fx = CANVAS_SIZE * 0.06;
    const fy = CANVAS_SIZE * 0.06;
    const fw = CANVAS_SIZE * 0.88;
    ctx.strokeStyle = rgbaOf("color2", 0.9);
    ctx.lineWidth = lw;
    ctx.strokeRect(fx, fy, fw, fw);

    if (frame === "rope" || frame === "chain") {
      const segs = 40;
      const step = fw / segs;
      for (let i = 0; i < segs; i++) {
        const t = i / segs;
        let ox, oy;
        if (i < segs / 4) { ox = fx + t * fw; oy = fy; }
        else if (i < segs / 2) { ox = fx + fw; oy = fy + (t - 0.25) * fw * 4; }
        else if (i < segs * 0.75) { ox = fx + fw - (t - 0.5) * fw * 4; oy = fy + fw; }
        else { ox = fx; oy = fy + fw - (t - 0.75) * fw * 4; }

        const flip = frame === "chain" && sgn(i) > 0;
        ctx.beginPath();
        if (flip) {
          ctx.arc(ox, oy, lw * 1.5, 0, Math.PI, true);
        } else {
          ctx.arc(ox, oy, lw * 1.5, 0, Math.PI);
        }
        ctx.strokeStyle = rgbaOf("color3", 0.8);
        ctx.stroke();
      }
    }
  }

  function sgn(n) { return n > 0 ? 1 : n < 0 ? -1 : 0; }

  /* =======================================================================
     STYLE 9 — TERRAZZO
     Scattered angular/rounded chips against a ground.
     ======================================================================= */
  function drawTerrazzo() {
    const dens = parseInt(terrazzoDensity.value, 10) / 100;
    const sizeMode = terrazzoSize.value;
    const shape = terrazzoShape.value;
    const sc = parseFloat(scale.value);

    // Ground
    ctx.fillStyle = rgbaOf("bg", 1);
    ctx.fillRect(0, 0, CANVAS_SIZE, CANVAS_SIZE);

    const baseChip = sizeMode === "fine" ? 8 : sizeMode === "medium" ? 16 : 30;
    const chipMax = baseChip * (0.7 + sc * 0.6);
    const count = Math.round(60 + dens * 220);

    for (let i = 0; i < count; i++) {
      const x = rng() * CANVAS_SIZE;
      const y = rng() * CANVAS_SIZE;
      const size = chipMax * (0.3 + rng() * 0.9);
      const color = pickColor(0.5, 0.95);
      ctx.fillStyle = color;

      const isRounded = shape === "rounded" || (shape === "mixed" && rng() < 0.5);

      if (isRounded) {
        ctx.beginPath();
        ctx.ellipse(x, y, size, size * (0.5 + rng() * 0.5), rng() * Math.PI, 0, Math.PI * 2);
        ctx.fill();
      } else {
        // angular polygon
        const sides = 3 + Math.floor(rng() * 4);
        ctx.beginPath();
        for (let s = 0; s < sides; s++) {
          const ang = (s / sides) * Math.PI * 2 + rng() * 0.5;
          const rr = size * (0.5 + rng() * 0.5);
          const px = x + Math.cos(ang) * rr;
          const py = y + Math.sin(ang) * rr;
          if (s === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath();
        ctx.fill();
      }
    }
  }

  /* =======================================================================
     STYLE 10 — HEX WEAVE
     Interlocking hexagon tiling.
     ======================================================================= */
  function drawHex() {
    const sc = parseFloat(scale.value);
    const lw = parseInt(lineWeight.value, 10);
    const rot = parseInt(rotation.value, 10) * Math.PI / 180;
    const sizeMode = hexScale.value;
    const weave = hexWeave.value;

    const R = (sizeMode === "small" ? 40 : sizeMode === "medium" ? 62 : 90) * (0.6 + sc * 0.5);
    const hr = R * 0.866;
    const cy = CANVAS_SIZE / 2;
    const cx = CANVAS_SIZE / 2;

    for (let row = -3; row < CANVAS_SIZE / (R * 1.5) + 3; row++) {
      for (let col = -3; col < CANVAS_SIZE / (hr * 2) + 3; col++) {
        let x = col * hr * 2 + (row % 2 === 0 ? 0 : hr);
        let y = row * R * 1.5;

        const dx = x - cx;
        const dy = y - cy;
        x = cx + dx * Math.cos(rot) - dy * Math.sin(rot);
        y = cy + dx * Math.sin(rot) + dy * Math.cos(rot);

        if (x < -R * 3 || x > CANVAS_SIZE + R * 3) continue;
        if (y < -R * 3 || y > CANVAS_SIZE + R * 3) continue;

        const idx = row + col;
        ctx.strokeStyle = rgbaOf("color" + (((idx % 4) + 4) % 4 + 1), 0.75);

        if (weave === "filled") {
          ctx.fillStyle = rgbaOf("color" + (((idx % 4) + 4) % 4 + 1), 0.15);
        }

        ctx.lineWidth = lw;
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const a = (i / 6) * Math.PI * 2 + Math.PI / 6;
          const px = x + Math.cos(a) * R;
          const py = y + Math.sin(a) * R;
          if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.closePath();
        if (weave === "filled") ctx.fill();
        if (weave !== "outline" || idx % 3 === 0) ctx.stroke();
      }
    }

    // Over-under weave cross-lines
    if (weave === "over") {
      ctx.strokeStyle = rgbaOf("color3", 0.5);
      ctx.lineWidth = Math.max(1, lw * 0.7);
      for (let row = -3; row < CANVAS_SIZE / (R * 1.5) + 3; row++) {
        for (let col = -3; col < CANVAS_SIZE / (hr * 2) + 3; col++) {
          let x = col * hr * 2 + (row % 2 === 0 ? 0 : hr);
          let y = row * R * 1.5;
          const dx = x - cx, dy = y - cy;
          x = cx + dx * Math.cos(rot) - dy * Math.sin(rot);
          y = cy + dx * Math.sin(rot) + dy * Math.cos(rot);
          if ((row + col) % 2 === 0) {
            ctx.beginPath();
            ctx.moveTo(x - hr, y);
            ctx.lineTo(x + hr, y);
            ctx.stroke();
          }
        }
      }
    }
  }

  /* =======================================================================
     STYLE-SPECIFIC GROUP VISIBILITY
     ======================================================================= */
  function updateStyleGroups() {
    const style = patternStyle.value;
    styleIslamic.classList.toggle("hidden", style !== "islamic");
    styleCeltic.classList.toggle("hidden", style !== "celtic");
    styleMotif.classList.toggle("hidden", style !== "motif");
    styleProcedural.classList.toggle("hidden", style !== "procedural");
    styleLattice.classList.toggle("hidden", style !== "lattice");
    styleSpiral.classList.toggle("hidden", style !== "spiral");
    styleGlass.classList.toggle("hidden", style !== "glass");
    styleMedallion.classList.toggle("hidden", style !== "medallion");
    styleTerrazzo.classList.toggle("hidden", style !== "terrazzo");
    styleHex.classList.toggle("hidden", style !== "hex");
  }

  /* =======================================================================
     RENDER
     ======================================================================= */
  function drawCurrentStyle() {
    const style = patternStyle.value;
    if (style === "islamic") drawIslamic();
    else if (style === "celtic") drawCeltic();
    else if (style === "motif") drawMotif();
    else if (style === "procedural") drawProcedural();
    else if (style === "lattice") drawLattice();
    else if (style === "spiral") drawSpiral();
    else if (style === "glass") drawGlass();
    else if (style === "medallion") drawMedallion();
    else if (style === "terrazzo") drawTerrazzo();
    else if (style === "hex") drawHex();
  }

  function renderPreview() {
    reseed();
    prepareContext(ctx);
    paintBackground(ctx);
    drawCurrentStyle();
    resetDrawingState(ctx);
  }

  function renderForExport(withBackground) {
    const mult = parseInt(exportScale.value, 10) || 1;
    const out = document.createElement("canvas");
    out.width = CANVAS_SIZE * mult;
    out.height = CANVAS_SIZE * mult;
    const octx = out.getContext("2d");

    octx.clearRect(0, 0, out.width, out.height);

    const savedCtx = ctx;
    ctx = octx;
    reseed();
    octx.setTransform(1, 0, 0, 1, 0, 0);
    octx.globalAlpha = 1;
    octx.globalCompositeOperation = "source-over";
    octx.lineCap = "butt";
    octx.lineJoin = "miter";
    octx.scale(mult, mult);

    if (withBackground) paintBackground(ctx);
    drawCurrentStyle();
    resetDrawingState(ctx);

    ctx = savedCtx;
    return out;
  }

  let renderTimer = null;
  function scheduleRender() {
    if (renderTimer) clearTimeout(renderTimer);
    renderTimer = setTimeout(renderPreview, 60);
  }

  /* =======================================================================
     WIRE CONTROLS
     ======================================================================= */
  function wireControls() {
    [
      [scale, valScale],
      [density, valDensity],
      [lineWeight, valLineWeight],
      [mutationRate, valMutationRate],
      [spiralCurvature, valSpiralCurvature],
      [glassOutline, valGlassOutline],
      [terrazzoDensity, valTerrazzoDensity]
    ].forEach(([input, span]) => {
      input.addEventListener("input", () => {
        span.textContent = input.value;
        scheduleRender();
      });
    });

    [
      patternStyle, symmetry, rotation,
      starPoints, ringCount, tessellation,
      weaveStyle, loopCount, ribbonWidth,
      motifType, tileRotation, tileOffset,
      ruleSet, growthSteps, bgDir,
      latticeStyle, latticeWeave,
      spiralArms, spiralType,
      glassCells, glassStyle,
      medallionRings, medallionPoints, medallionFrame,
      terrazzoSize, terrazzoShape,
      hexScale, hexWeave
    ].forEach(el => {
      el.addEventListener("change", () => {
        if (el === patternStyle) updateStyleGroups();
        scheduleRender();
      });
    });

    bgStyle.addEventListener("change", () => {
      updateBgControls();
      scheduleRender();
    });

    colorScheme.addEventListener("change", () => {
      applyColorScheme(colorScheme.value);
      scheduleRender();
    });

    colorTabs.forEach(btn => {
      btn.addEventListener("click", () => setActiveSlot(btn.dataset.slot));
    });

    if (activeColorSwatch) {
      activeColorSwatch.addEventListener("click", () => {
        CP.open("activeColorSlot", SLOT_LABELS[activeSlot] || activeSlot, colors[activeSlot], function(hex) {
          colors[activeSlot] = hex;
          activeColorInput.value = hex;
          updateColorEditor();
          scheduleRender();
        });
      });
    }

    hueSlider.addEventListener("input", applyHslUpdate);
    satSlider.addEventListener("input", applyHslUpdate);
    lightSlider.addEventListener("input", applyHslUpdate);

    opacitySlider.addEventListener("input", () => {
      opacities[activeSlot] = parseInt(opacitySlider.value, 10);
      valOpacity.textContent = opacitySlider.value;
      scheduleRender();
    });

    seed.addEventListener("input", scheduleRender);

    btnRandomizeSeed.addEventListener("click", () => {
      seed.value = randomSeedString();
      scheduleRender();
    });

    btnRandomizeTop.addEventListener("click", () => {
      seed.value = randomSeedString();
      scheduleRender();
    });

    btnRandomizeAll.addEventListener("click", randomizeAll);
  }

  function applyHslUpdate() {
    const h = parseInt(hueSlider.value, 10);
    const s = parseInt(satSlider.value, 10);
    const l = parseInt(lightSlider.value, 10);

    valHue.textContent = h;
    valSat.textContent = s;
    valLight.textContent = l;

    colors[activeSlot] = hslToHex(h, s, l);
    activeColorInput.value = colors[activeSlot];
    updateColorEditor();
    scheduleRender();
  }

  function pick(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  function randomSeedString() {
    const words = ["vorifex", "tithe", "ember", "ashen", "silent", "crown", "iron", "crimson", "veil", "stone", "shadow", "hollow", "gilded", "oath"];
    const w = pick(words);
    const n = Math.floor(Math.random() * 9999);
    return w + "-" + n;
  }

  function randomizeAll() {
    // Randomize everything EXCEPT Size / export settings.

    seed.value = randomSeedString();

    patternStyle.value = pick(["islamic", "celtic", "motif", "procedural", "lattice", "spiral", "glass", "medallion", "terrazzo", "hex"]);

    colorScheme.value = pick(ALL_SCHEMES);
    applyColorScheme(colorScheme.value);

    symmetry.value = String(pick([4, 6, 8, 12, 16, 24]));
    scale.value = (0.5 + Math.random() * 1.8).toFixed(2);
    density.value = String(Math.round(15 + Math.random() * 70));
    lineWeight.value = String(Math.round(1 + Math.random() * 14));
    rotation.value = pick(["0", "15", "30", "45", "90"]);

    starPoints.value = pick(["6", "8", "10", "12"]);
    ringCount.value = pick(["2", "3", "4", "5"]);
    tessellation.value = pick(["star", "polygon", "mixed"]);

    weaveStyle.value = pick(["over", "balanced", "dense"]);
    loopCount.value = pick(["2", "3", "4", "5"]);
    ribbonWidth.value = pick(["thin", "medium", "thick"]);

    motifType.value = pick(["dot", "diamond", "petal", "arrow", "eye"]);
    tileRotation.value = pick(["0", "90", "180", "mirror"]);
    tileOffset.value = pick(["none", "brick", "diagonal"]);

    ruleSet.value = pick(["truchet", "cellular", "flow", "branch"]);
    mutationRate.value = String(Math.round(Math.random() * 100));
    growthSteps.value = pick(["3", "5", "8", "12"]);

    latticeStyle.value = pick(["diamond", "square", "hexagonal"]);
    latticeWeave.value = pick(["over", "flat", "gap"]);

    spiralArms.value = pick(["3", "5", "7", "9", "12"]);
    spiralType.value = pick(["rose", "vortex", "fern"]);
    spiralCurvature.value = String(Math.round(20 + Math.random() * 70));

    glassCells.value = pick(["coarse", "medium", "fine"]);
    glassStyle.value = pick(["mosaic", "fractured", "circular"]);
    glassOutline.value = String(Math.round(1 + Math.random() * 10));

    medallionRings.value = pick(["2", "3", "4", "5"]);
    medallionPoints.value = pick(["6", "8", "10", "12"]);
    medallionFrame.value = pick(["rope", "chain", "plain"]);

    terrazzoDensity.value = String(Math.round(20 + Math.random() * 70));
    terrazzoSize.value = pick(["fine", "medium", "coarse"]);
    terrazzoShape.value = pick(["angular", "rounded", "mixed"]);

    hexScale.value = pick(["small", "medium", "large"]);
    hexWeave.value = pick(["over", "outline", "filled"]);

    bgStyle.value = pick(["solid", "linear", "radial"]);
    bgDir.value = pick(["to-bottom", "to-top", "to-right", "to-left", "to-bottom-right", "to-bottom-left", "to-top-right", "to-top-left"]);

    valScale.textContent = scale.value;
    valDensity.textContent = density.value;
    valLineWeight.textContent = lineWeight.value;
    valMutationRate.textContent = mutationRate.value;
    valSpiralCurvature.textContent = spiralCurvature.value;
    valGlassOutline.textContent = glassOutline.value;
    valTerrazzoDensity.textContent = terrazzoDensity.value;

    updateStyleGroups();
    updateBgControls();
    scheduleRender();
  }

  /* =======================================================================
     EXPORT
     ======================================================================= */
  function exportImage(format) {
    const useTransparent = format === "png" && exportBg.value === "transparent";
    const out = renderForExport(!useTransparent);

    const mime = format === "jpg" ? "image/jpeg" : "image/png";
    const quality = format === "jpg" ? 0.92 : undefined;
    const dataUrl = out.toDataURL(mime, quality);

    const a = document.createElement("a");
    a.href = dataUrl;
    a.download = (exportName.value || "pattern") + "." + (format === "jpg" ? "jpg" : "png");
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  btnExportPng.addEventListener("click", () => exportImage("png"));
  btnExportJpg.addEventListener("click", () => exportImage("jpg"));

  btnCopySeed.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(seed.value);
      const original = btnCopySeed.textContent;
      btnCopySeed.textContent = "Copied!";
      setTimeout(() => { btnCopySeed.textContent = original; }, 1200);
    } catch (e) {
      prompt("Copy the seed below:", seed.value);
    }
  });

  /* =======================================================================
     FULL-SETTINGS PRESETS
     ======================================================================= */
  const PRESET_KEY = "pattern_weaver_presets_v3";
  const OLD_PRESET_KEY = "pattern_weaver_presets_v2";

  function sanitizeColors(obj) {
    const out = Object.assign({}, colors);
    if (!obj) return out;
    ALL_SLOTS.forEach(slot => {
      const v = obj[slot];
      if (typeof v === "string" && /^#[0-9a-fA-F]{3,6}$/.test(v)) out[slot] = v;
    });
    return out;
  }

  function sanitizeOpacities(obj) {
    const out = Object.assign({}, opacities);
    if (!obj) return out;
    ALL_SLOTS.forEach(slot => {
      const v = obj[slot];
      if (typeof v === "number" && isFinite(v)) out[slot] = clamp(Math.round(v), 0, 100);
    });
    return out;
  }

  function loadPresets() {
    try {
      const raw = localStorage.getItem(PRESET_KEY);
      if (raw) return JSON.parse(raw);
      const oldRaw = localStorage.getItem(OLD_PRESET_KEY);
      if (oldRaw) {
        return JSON.parse(oldRaw);
      }
    } catch (e) {}
    return {};
  }

  function savePresets(obj) {
    try {
      localStorage.setItem(PRESET_KEY, JSON.stringify(obj));
    } catch (e) {}
  }

  function refreshPresetList() {
    const presets = loadPresets();
    presetList.innerHTML = '<option value="">— none —</option>';
    Object.keys(presets).forEach(name => {
      const opt = document.createElement("option");
      opt.value = name;
      opt.textContent = name;
      presetList.appendChild(opt);
    });
  }

  function collectCurrentSettings() {
    return {
      patternStyle: patternStyle.value,
      seed: seed.value,
      symmetry: symmetry.value,
      scale: scale.value,
      density: density.value,
      lineWeight: lineWeight.value,
      rotation: rotation.value,
      starPoints: starPoints.value,
      ringCount: ringCount.value,
      tessellation: tessellation.value,
      weaveStyle: weaveStyle.value,
      loopCount: loopCount.value,
      ribbonWidth: ribbonWidth.value,
      motifType: motifType.value,
      tileRotation: tileRotation.value,
      tileOffset: tileOffset.value,
      ruleSet: ruleSet.value,
      mutationRate: mutationRate.value,
      growthSteps: growthSteps.value,
      latticeStyle: latticeStyle.value,
      latticeWeave: latticeWeave.value,
      spiralArms: spiralArms.value,
      spiralType: spiralType.value,
      spiralCurvature: spiralCurvature.value,
      glassCells: glassCells.value,
      glassStyle: glassStyle.value,
      glassOutline: glassOutline.value,
      medallionRings: medallionRings.value,
      medallionPoints: medallionPoints.value,
      medallionFrame: medallionFrame.value,
      terrazzoDensity: terrazzoDensity.value,
      terrazzoSize: terrazzoSize.value,
      terrazzoShape: terrazzoShape.value,
      hexScale: hexScale.value,
      hexWeave: hexWeave.value,
      bgStyle: bgStyle.value,
      bgDir: bgDir.value,
      colors: Object.assign({}, colors),
      opacities: Object.assign({}, opacities)
    };
  }

  function applySettings(s) {
    if (!s) return;

    const scalarFields = [
      "patternStyle", "seed", "symmetry", "scale", "density", "lineWeight",
      "rotation", "starPoints", "ringCount", "tessellation", "weaveStyle",
      "loopCount", "ribbonWidth", "motifType", "tileRotation", "tileOffset",
      "ruleSet", "mutationRate", "growthSteps", "bgStyle", "bgDir",
      "latticeStyle", "latticeWeave", "spiralArms", "spiralType", "spiralCurvature",
      "glassCells", "glassStyle", "glassOutline", "medallionRings", "medallionPoints",
      "medallionFrame", "terrazzoDensity", "terrazzoSize", "terrazzoShape",
      "hexScale", "hexWeave"
    ];

    scalarFields.forEach(f => {
      const el = document.getElementById(f);
      if (el && s[f] !== undefined) {
        el.value = s[f];
        const span = document.getElementById("val" + f.charAt(0).toUpperCase() + f.slice(1));
        if (span && el.type === "range") span.textContent = s[f];
      }
    });

    Object.assign(colors, sanitizeColors(s.colors));
    Object.assign(opacities, sanitizeOpacities(s.opacities));

    if (scale && s.scale !== undefined) valScale.textContent = scale.value;
    if (density && s.density !== undefined) valDensity.textContent = density.value;
    if (lineWeight && s.lineWeight !== undefined) valLineWeight.textContent = lineWeight.value;
    if (mutationRate && s.mutationRate !== undefined) valMutationRate.textContent = mutationRate.value;

    updateBgControls();
    updateStyleGroups();
    scheduleRender();
  }

  btnSavePreset.addEventListener("click", () => {
    const name = prompt("Name this full preset:");
    if (!name) return;
    const presets = loadPresets();
    presets[name] = collectCurrentSettings();
    savePresets(presets);
    refreshPresetList();
    presetList.value = name;
  });

  btnLoadPreset.addEventListener("click", () => {
    const name = presetList.value;
    if (!name) return;
    const presets = loadPresets();
    if (presets[name]) applySettings(presets[name]);
  });

  btnDeletePreset.addEventListener("click", () => {
    const name = presetList.value;
    if (!name) return;
    if (!confirm(`Delete preset "${name}"?`)) return;
    const presets = loadPresets();
    delete presets[name];
    savePresets(presets);
    refreshPresetList();
  });

  /* =======================================================================
     CUSTOM COLOR PALETTES
     ======================================================================= */
  const PALETTE_KEY = "pattern_weaver_palettes_v2";

  function loadPalettes() {
    try {
      const raw = localStorage.getItem(PALETTE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (e) { return {}; }
  }

  function savePalettes(obj) {
    try {
      localStorage.setItem(PALETTE_KEY, JSON.stringify(obj));
    } catch (e) {}
  }

  function refreshPaletteList() {
    const palettes = loadPalettes();
    palettePresetList.innerHTML = '<option value="">— none —</option>';
    Object.keys(palettes).forEach(name => {
      const opt = document.createElement("option");
      opt.value = name;
      opt.textContent = name;
      palettePresetList.appendChild(opt);
    });
  }

  function collectCurrentPalette() {
    return {
      colors: Object.assign({}, colors),
      opacities: Object.assign({}, opacities),
      bgStyle: bgStyle.value,
      bgDir: bgDir.value
    };
  }

  function applyPalette(p) {
    if (!p) return;
    Object.assign(colors, sanitizeColors(p.colors));
    Object.assign(opacities, sanitizeOpacities(p.opacities));
    if (p.bgStyle && bgStyle) bgStyle.value = p.bgStyle;
    if (p.bgDir && bgDir) bgDir.value = p.bgDir;
    updateBgControls();
    scheduleRender();
  }

  btnSavePalette.addEventListener("click", () => {
    const name = prompt("Name this color palette:");
    if (!name) return;
    const palettes = loadPalettes();
    palettes[name] = collectCurrentPalette();
    savePalettes(palettes);
    refreshPaletteList();
    palettePresetList.value = name;
  });

  btnLoadPalette.addEventListener("click", () => {
    const name = palettePresetList.value;
    if (!name) return;
    const palettes = loadPalettes();
    if (palettes[name]) applyPalette(palettes[name]);
  });

  btnDeletePalette.addEventListener("click", () => {
    const name = palettePresetList.value;
    if (!name) return;
    if (!confirm(`Delete palette "${name}"?`)) return;
    const palettes = loadPalettes();
    delete palettes[name];
    savePalettes(palettes);
    refreshPaletteList();
  });

  /* =======================================================================
     INIT
     ======================================================================= */
  function init() {
    wireControls();
    updateStyleGroups();
    refreshPresetList();
    refreshPaletteList();
    updateBgControls();

    valScale.textContent = scale.value;
    valDensity.textContent = density.value;
    valLineWeight.textContent = lineWeight.value;
    valMutationRate.textContent = mutationRate.value;
    valSpiralCurvature.textContent = spiralCurvature.value;
    valGlassOutline.textContent = glassOutline.value;
    valTerrazzoDensity.textContent = terrazzoDensity.value;

    renderPreview();
  }

  init();

  /* =======================================================================
     CUSTOM COLOR PICKER
     Replaces native <input type="color"> — works identically on every browser.
     ======================================================================= */
  const CP = {
    overlay:    document.getElementById("colorPickerOverlay"),
    slCanvas:   document.getElementById("cpSLCanvas"),
    hueCanvas:  document.getElementById("cpHueCanvas"),
    slCursor:   document.getElementById("cpSLCursor"),
    hueCursor:  document.getElementById("cpHueCursor"),
    hexInput:   document.getElementById("cpHexInput"),
    hexPreview: document.getElementById("cpHexPreview"),
    presets:    document.getElementById("cpPresets"),
    title:      document.getElementById("cpTitle"),
    h: 0, s: 100, l: 50,
    _cb: null,

    PRESETS: [
      "#7c5cff","#38bdf8","#f472b6","#ffd257","#34d399",
      "#f97316","#ef4444","#a855f7","#06b6d4","#22c55e",
      "#ffffff","#94a3b8","#475569","#1e293b","#000000",
      "#fde68a","#bbf7d0","#bfdbfe","#ddd6fe","#fce7f3"
    ],

    open: function(id, label, currentHex, callback) {
      this._cb = callback;
      this.title.textContent = "Pick: " + label;
      const rgb = hexToRgb(currentHex || "#7c5cff");
      const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
      this.h = hsl.h; this.s = hsl.s; this.l = hsl.l;
      this.overlay.classList.remove("hidden");
      const self = this;
      requestAnimationFrame(function() {
        self.drawHue();
        self.drawSL();
        self.updateCursors();
        self.buildPresets();
      });
    },

    drawHue: function() {
      const c = this.hueCanvas;
      c.width = c.offsetWidth || 260;
      c.height = c.offsetHeight || 24;
      const cx = c.getContext("2d");
      const g = cx.createLinearGradient(0, 0, c.width, 0);
      for (let i = 0; i <= 12; i++) g.addColorStop(i/12, "hsl("+(i/12*360)+",100%,50%)");
      cx.fillStyle = g;
      cx.fillRect(0, 0, c.width, c.height);
    },

    drawSL: function() {
      const c = this.slCanvas;
      c.width = c.offsetWidth || 260;
      c.height = c.offsetHeight || 200;
      const cx = c.getContext("2d");
      const gH = cx.createLinearGradient(0, 0, c.width, 0);
      gH.addColorStop(0, "hsl("+this.h+",0%,100%)");
      gH.addColorStop(1, "hsl("+this.h+",100%,50%)");
      cx.fillStyle = gH; cx.fillRect(0, 0, c.width, c.height);
      const gV = cx.createLinearGradient(0, 0, 0, c.height);
      gV.addColorStop(0, "rgba(0,0,0,0)");
      gV.addColorStop(1, "rgba(0,0,0,1)");
      cx.fillStyle = gV; cx.fillRect(0, 0, c.width, c.height);
    },

    slFromPos: function(x, y) {
      const w = this.slCanvas.width || 260;
      const h = this.slCanvas.height || 200;
      const sx = Math.max(0, Math.min(1, x/w));
      const ly = Math.max(0, Math.min(1, y/h));
      let lightness = (1 - ly) * (1 - sx/2) * 100;
      let saturation = sx === 0 ? 0 : (100 * sx * (1 - ly)) / (1 - Math.abs(2*lightness/100 - 1) + 1e-9);
      return { s: Math.max(0, Math.min(100, saturation)), l: Math.max(0, Math.min(100, lightness)) };
    },

    posFromSL: function() {
      const w = this.slCanvas.width || 260;
      const h = this.slCanvas.height || 200;
      const lNorm = this.l/100, sNorm = this.s/100;
      let x = sNorm * (1 - Math.abs(2*lNorm-1)) / (2*lNorm*(1-lNorm) + 1e-9);
      x = Math.max(0, Math.min(1, x));
      let ly = 1 - lNorm / (1 - x/2 + 1e-9);
      ly = Math.max(0, Math.min(1, ly));
      return { x: x*w, y: ly*h };
    },

    toHex: function() {
      const c = hslToRgb(this.h, this.s, this.l);
      return rgbToHex(c.r, c.g, c.b);
    },

    updateCursors: function() {
      const hueW = this.hueCanvas.width || 260;
      this.hueCursor.style.left = (this.h/360 * hueW) + "px";
      const pos = this.posFromSL();
      this.slCursor.style.left = pos.x + "px";
      this.slCursor.style.top  = pos.y + "px";
      const hex = this.toHex();
      this.hexInput.value   = hex.slice(1);
      this.hexPreview.style.background = hex;
    },

    buildPresets: function() {
      const self = this;
      this.presets.innerHTML = "";
      this.PRESETS.forEach(function(hex) {
        const btn = document.createElement("button");
        btn.className = "cpPresetSwatch";
        btn.style.background = hex;
        btn.addEventListener("click", function() {
          const rgb = hexToRgb(hex);
          const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
          self.h = hsl.h; self.s = hsl.s; self.l = hsl.l;
          self.drawSL();
          self.updateCursors();
        });
        self.presets.appendChild(btn);
      });
    },

    apply: function() {
      const hex = this.toHex();
      if (this._cb) this._cb(hex);
      this.overlay.classList.add("hidden");
    },

    close: function() {
      this.overlay.classList.add("hidden");
    }
  };

  // Hue strip events
  function cpHuePos(e) {
    const rect = CP.hueCanvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    return Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
  }
  function onCPHue(e) {
    e.preventDefault();
    CP.h = cpHuePos(e) * 360;
    CP.drawSL();
    CP.updateCursors();
  }
  CP.hueCanvas.addEventListener("mousedown",  function(e){ onCPHue(e); CP.hueCanvas.addEventListener("mousemove", onCPHue); });
  CP.hueCanvas.addEventListener("touchstart", function(e){ onCPHue(e); CP.hueCanvas.addEventListener("touchmove", onCPHue); }, {passive:false});
  document.addEventListener("mouseup",  function(){ CP.hueCanvas.removeEventListener("mousemove", onCPHue); });
  document.addEventListener("touchend", function(){ CP.hueCanvas.removeEventListener("touchmove", onCPHue); });

  // SL square events
  function cpSLPos(e) {
    const rect = CP.slCanvas.getBoundingClientRect();
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return { x: clientX - rect.left, y: clientY - rect.top };
  }
  function onCPSL(e) {
    e.preventDefault();
    const pos = cpSLPos(e);
    const sl = CP.slFromPos(pos.x, pos.y);
    CP.s = sl.s; CP.l = sl.l;
    CP.updateCursors();
  }
  CP.slCanvas.addEventListener("mousedown",  function(e){ onCPSL(e); CP.slCanvas.addEventListener("mousemove", onCPSL); });
  CP.slCanvas.addEventListener("touchstart", function(e){ onCPSL(e); CP.slCanvas.addEventListener("touchmove", onCPSL); }, {passive:false});
  document.addEventListener("mouseup",  function(){ CP.slCanvas.removeEventListener("mousemove", onCPSL); });
  document.addEventListener("touchend", function(){ CP.slCanvas.removeEventListener("touchmove", onCPSL); });

  // Hex input
  CP.hexInput.addEventListener("input", function() {
    const val = CP.hexInput.value.replace(/[^0-9a-fA-F]/g,"");
    if (val.length === 6) {
      const rgb = hexToRgb("#"+val);
      const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);
      CP.h = hsl.h; CP.s = hsl.s; CP.l = hsl.l;
      CP.drawSL();
      CP.updateCursors();
    }
  });

  document.getElementById("cpApply").addEventListener("click", function() { CP.apply(); });
  document.getElementById("cpCancel").addEventListener("click", function() { CP.close(); });
  CP.overlay.addEventListener("click", function(e) {
    if (e.target === CP.overlay) CP.close();
  });

})();