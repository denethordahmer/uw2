window.Delve = window.Delve || {};
(function(){

 const def = function(id){
 return (Delve.CONFIG.STATUS_EFFECTS || {})[id];
 };

 // ── Apply a status to a monster or boss ──────────────────────
 Delve.applyEffect = function(target, id){
 const d = def(id);
 if(!d || !target) return false;
 target.effects = target.effects || [];
 // Bleed inflicted by the player lasts longer with the Bloodletter passive.
 // Only bleed, and only on monsters — the player's own bleed is unaffected.
 let turns = d.turns;
 if(id === "bleed" && target !== Delve.G && Delve.traitBuffs){
  turns += Math.round(Delve.traitBuffs().bleedExtra || 0);
 }
 if(d.stackable){
 target.effects.push({ id: id, turns: turns });
 } else {
 const existing = target.effects.find(e => e.id === id);
 if(existing) existing.turns = Math.max(existing.turns, turns);
 else target.effects.push({ id: id, turns: turns });
 }
 if(Delve.sfx) Delve.sfx("status_proc", { status: id });
 return true;
 };

 // ── Tick monster DOTs at the START of its swing cycle ────────
 // Returns true if the monster died from the damage-over-time.
 Delve.tickMonsterEffects = function(m){
 if(!m.effects || !m.effects.length) return false;
 let died = false;

 for(const e of m.effects){
 const d = def(e.id);
 if(!d) continue;
 if(d.perTurn){
 m.hp -= d.perTurn;
 if(Delve.addFloater) Delve.addFloater(d.name + " -" + d.perTurn, m.x, m.y - 0.7, d.color);
 if(m.hp <= 0){ died = true; break; }
 }
 }

 m.effects = m.effects
 .map(e => ({ id: e.id, turns: e.turns - 1 }))
 .filter(e => e.turns > 0);

 return died;
 };

 // ── Advance player-side effects by one turn ──────────────────
 // Applies per-turn damage (poison, bleed, burn) then decrements.
 // Calls Delve.die() if HP reaches 0. Weaken has no perTurn and
 // therefore ticks its duration without dealing damage.
 Delve.tickPlayerEffects = function(){
 const G = Delve.G;
 if(!G.effects) G.effects = [];
 if(!G.effects.length) return G.effects;

 for(const e of G.effects){
 const d = def(e.id);
 if(!d || !d.perTurn) continue;
 if(Delve.sfx) Delve.sfx("dot_tick");
 G.hp -= d.perTurn;
 if(Delve.addFloater) Delve.addFloater(d.name + " -" + d.perTurn, G.px, G.py - 0.3, d.color);
 if(Delve.logSystem) Delve.logSystem(d.name + " ticks for " + d.perTurn + " HP.");
 if(G.hp <= 0){
 if(Delve.die) Delve.die();
 return G.effects;
 }
 }

 G.effects = G.effects
 .map(e => ({ id: e.id, turns: e.turns - 1 }))
 .filter(e => e.turns > 0);
 return G.effects;
 };

 // ── Apply a status to the player (e.g. Wraith's Weaken) ──────
 Delve.applyPlayerEffect = function(id){
 const G = Delve.G, d = def(id);
 if(!G || !d) return;
 G.effects = G.effects || [];
 // Grave Ward: bleed, poison and burn last half as long on the player. Weaken is
 // a debuff but not a damage-over-time, so it is deliberately not reduced.
 const resist = (Delve.traitBuffs && Delve.traitBuffs().statusResist) || 0;
 const isDot = (id === "bleed" || id === "poison" || id === "burn");
 const turns = isDot ? Math.max(1, Math.round(d.turns * (1 - resist))) : d.turns;
 const existing = G.effects.find(e => e.id === id);
 if(existing) existing.turns = Math.max(existing.turns, turns);
 else G.effects.push({ id: id, turns: turns });
 if(Delve.sfx) Delve.sfx("status_" + id);
 };

 // ── Active-debuff checks used by combat ─────────────────────
 Delve.playerWeakened = function(){
 const G = Delve.G;
 return !!(G.effects && G.effects.some(e => e.id === "weaken"));
 };

 // Chill halves attack speed. Read by items.js playerSpeed(); the penalty is a
 // multiplier on the final speed value, so it stacks sensibly with gear/agility.
 Delve.playerChilled = function(){
 const G = Delve.G;
 return !!(G.effects && G.effects.some(e => e.id === "chill"));
 };

 Delve.statusColor = function(id){
 const d = def(id);
 return d ? d.color : "#ffffff";
 };

})();
