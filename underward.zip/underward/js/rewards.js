window.Delve = window.Delve || {};
(function(){
 const C = () => Delve.CONFIG;
 const ECO = () => Delve.CONFIG.economy;

 // rewards.js : run economy — gold→shards, boss bonuses, kill rewards,
 // floor-clear bonuses, elite promotion, monster stat lookup.
 // Load AFTER js/combat.js (uses Delve.rowFor, exported from there).
 // Everything else it touches (save, recordStat, luckPts, logSystem) is
 // resolved at call time, so no other ordering constraint applies.

 // ── Gold → shards conversion (successful run ends) ──────────
 Delve.convertGold = function(rate){
 const G = Delve.G;
 const r = rate || ECO().goldToShardRate;
 const shards = Math.floor(G.gold / r);
 G.gold -= shards * r;
 // Run-earned shards accumulate in G.runShards ONLY. They reach save.shards at a
 // commit point — see Delve.bankRunShards() below. Never write save.shards here:
 // a mid-run refresh would then bank a run the player never finished.
 G.runShards += shards;
 return shards;
 };

 // ── Shard banking ────────────────────────────────────────────
 // Run-earned shards (kills, floor-clear bonuses, gold converted at a boss, the
 // boss's own bonus) live in G.runShards while the run is in progress and are NOT
 // in the save. They are committed to the save at a commit point only: dying,
 // retreating, or beating a ward boss. So refreshing mid-run loses the run's
 // earnings, exactly as it loses the run itself.
 //
 // "Banked" is tracked as an amount, not a boolean, so this is safe to call at
 // every commit point — each call commits only what accrued since the last one.
 Delve.pendingRunShards = function(){
 const G = Delve.G;
 if(!G) return 0;
 return Math.max(0, Math.round((G.runShards || 0) - (G.shardsBanked || 0)));
 };

 Delve.bankRunShards = function(){
 const G = Delve.G;
 if(!G || !Delve.save) return 0;
 const pending = Delve.pendingRunShards();
 if(pending <= 0){ G.shardsBanked = G.runShards || 0; return 0; }
 G.shardsBanked = (G.shardsBanked || 0) + pending;
 Delve.save.shards = Math.max(0, Math.round((Delve.save.shards || 0) + pending));
 Delve.persist();
 return pending;
 };

 // The old percentage boss bonus (bossDef.shardBonusPct × run shards) was REMOVED on 16 Oct
 // by the owner's call. Bosses now pay a flat, depth-scaled amount awarded as part of the
 // boss kill itself — see the boss branch of killRewards and CONFIG.economy.bossShardsPerWard.

 // ── Monster roster / rewards ────────────────────────────────
 Delve.monsterStats = function(type, floor){
 const cfg = Delve.CONFIG;
 const row = cfg.MONSTER_ROSTER[type] || cfg.MONSTER_ROSTER.goblin;
 return {
 name: row.name,
 kind: row.kind,
 hp: Math.round(row.hp + row.hpPerFloor * (floor - 1)),
 atk: Math.max(1, Math.round(row.atk + row.atkPerFloor * floor)),
 xp: row.xp,
 shards: row.shards,
 gold: row.gold
 };
 };

 Delve.killRewards = function(m){
 const G = Delve.G, cfg = Delve.CONFIG, eco = cfg.economy;
 const floor = G.floor;
 const luckMult = 1 + Delve.luckPts() * (eco.goldLuckMult || 0.05);

 let gold, shards, xp;

 if(m.isBoss){
 gold = cfg.goldBossBase || 80;
 // Flat, depth-scaled payout: 30 for boss 1, then +30 per boss (30, 60, 90 … 300 at
 // floor 100). Not a percentage — the old shardBonusPct system was removed on 16 Oct
 // so the reward is one readable number needing no re-tuning per ward.
 const ward = Math.max(1, Math.ceil(floor / 10));
 const bossDef = cfg.BOSS_DEFS[ward];
 shards = (bossDef && bossDef.shardReward) || (eco.bossShardsPerWard || 30) * ward;
 xp = (cfg.xpKill && cfg.xpKill.boss) || 30;
 } else {
 const row = Delve.rowFor(m.kind); // exported by js/combat.js
 gold = row.gold + (eco.goldCurveK || 3.0) * Math.log(floor + 1);
 shards = row.shards;
 xp = row.xp;
 }

 if(m.elite){
 const r = cfg.elite.rewardMult || 3;
 gold *= r; shards *= r; xp *= r;
 }

 // "Bonus Shards" gear. Same story as Item Find: the stat rolled, was summed into
 // itemBuffs.shardBonus, and nothing ever paid it. It is a percentage of the
 // kill's shard value, so it scales with depth like everything else and cannot
 // be farmed on floor 1.
 let shardPct = 0;
 if(!m.isBoss && Delve.itemBuffs){ shardPct = Delve.itemBuffs().shardBonus || 0; }
 if(shardPct) shards *= (1 + shardPct);

 return {
 gold: Math.round(gold * luckMult),
 shards: Math.round(shards),
 xp: Math.round(xp)
 };
 };

 // ── Depth damage curve ───────────────────────────────────────
 // One multiplier on every monster's and boss's ATTACK, applied at spawn time.
 // `enemyDmgPerWard` is 15%, so ward 1 is unchanged and ward 5 hits for 1.6×.
 // This lives here rather than in levels.js because the boss path also needs it,
 // and both spawns already read js/rewards.js for their stat lookups.
 Delve.depthAtk = function(atk, floor){
  const per = (Delve.CONFIG && Delve.CONFIG.enemyDmgPerWard) || 0;
  if(!per) return Math.max(1, Math.round(atk));
  const f = Math.max(1, Number(floor) || 1);
  const ward = Math.max(1, Math.ceil(f / 10));
  return Math.max(1, Math.round(atk * (1 + per * (ward - 1))));
 };

 Delve.floorClearBonus = function(){
 const G = Delve.G, eco = Delve.CONFIG.economy;
 return (eco.floorClearBonus || 0) + (eco.floorClearBonusPerFloor || 0) * G.floor;
 };

 // Potion drop chance for the floor the player is on. Tapers by ward (see
 // CONFIG.ITEMS.drop.potionByWard) so deep floors cannot be patched up by the
 // next few kills. Falls back to the flat `potion` value when no table exists.
 Delve.potionDropChance = function(floor){
 const d = ((Delve.CONFIG.ITEMS || {}).drop) || {};
 const table = d.potionByWard;
 if(!table) return d.potion || 0;
 const f = (floor === undefined || floor === null) ? ((Delve.G && Delve.G.floor) || 1) : floor;
 const ward = Math.max(1, Math.min(5, Math.ceil(f / 10)));
 return (table[ward] !== undefined) ? table[ward] : (d.potion || 0);
 };

 Delve.makeElite = function(m){
 const e = Delve.CONFIG.elite;
 m.elite = true;
 m.maxHp = Math.round(m.maxHp * e.hpMult);
 m.hp = m.maxHp;
 m.atk = Math.max(1, Math.round(m.atk * e.atkMult));
 m.name = "Elite " + m.name;
 if(Delve.sfx) Delve.sfx("elite");
 return m;
 };
})();
